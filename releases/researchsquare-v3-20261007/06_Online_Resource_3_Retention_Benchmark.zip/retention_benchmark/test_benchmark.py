"""Toy data only. No real archive or outcome values are loaded."""
import itertools
import unittest
import numpy as np
from benchmark_core import BITS, length_band, moments, sample_hits


class TestFinitePopulation(unittest.TestCase):
    def test_length_boundaries(self):
        self.assertEqual([length_band(x) for x in [0, 69, 70, 350, 351, 700, 701, 1200, 1201]],
                         [0, 0, 1, 1, 2, 2, 3, 3, 4])

    def test_exhaustive_marginal_moments(self):
        patterns = np.array([0, 1, 1, 2, 3, 7])
        colors = np.bincount(patterns, minlength=8)
        for k in range(len(patterns) + 1):
            hits = np.array([BITS[patterns[list(ix)]].sum(axis=0) for ix in itertools.combinations(range(len(patterns)), k)])
            mean, var = moments(colors, k)
            np.testing.assert_allclose(hits.mean(axis=0), mean, atol=1e-14)
            np.testing.assert_allclose(hits.var(axis=0), var, atol=1e-14)

    def test_deterministic_edges(self):
        colors = np.array([2, 1, 0, 1, 0, 0, 0, 1])
        rng = np.random.default_rng(74)
        self.assertTrue(np.all(sample_hits(colors, 0, rng, 20) == 0))
        np.testing.assert_array_equal(sample_hits(colors, 5, rng, 20), np.tile(colors @ BITS, (20, 1)))

    def test_simulation_matches_enumeration(self):
        colors = np.array([2, 1, 1, 1, 0, 0, 0, 1])
        mean, var = moments(colors, 3)
        draws = sample_hits(colors, 3, np.random.default_rng(9201), 100000)
        np.testing.assert_allclose(draws.mean(axis=0), mean, atol=0.01)
        np.testing.assert_allclose(draws.var(axis=0), var, atol=0.01)

    def test_joint_features_preserve_correlation(self):
        colors = np.zeros(8, dtype=int)
        colors[0], colors[7] = 12, 8
        draws = sample_hits(colors, 7, np.random.default_rng(14), 1000)
        np.testing.assert_array_equal(draws[:, 0], draws[:, 1])
        np.testing.assert_array_equal(draws[:, 1], draws[:, 2])


if __name__ == '__main__':
    unittest.main()
