"""Recompute declared primary contrasts from public original replication data.

No upstream R/SPSS code is executed. The R/SPSS scripts and reports are read-only
specifications. This is a transparent Python statistical audit, not new human
annotation and not a preregistered analysis. Nothing is silently recoded.
"""
from pathlib import Path
import sys, json, hashlib, datetime, importlib.metadata
import numpy as np
import pandas as pd
from scipy import stats
import pyreadstat
ROOT=Path(__file__).resolve().parent;DATA=ROOT/'ambiguous_data'
OUT=ROOT/'target_recomputations';OUT.mkdir(exist_ok=True)
manifest=json.loads((DATA/'manifest.json').read_text())
def input_for(sid,suffix):
 files=[x for x in manifest if x['source_id'].startswith(sid+'.') and x['name'].endswith(suffix)]
 assert len(files)==1,(sid,suffix,files)
 x=files[0];p=ROOT/x['local_path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
 return p,x
inputs=[]
def load(sid,suffix):
 p,x=input_for(sid,suffix);inputs.append(x)
 if suffix.endswith('.sav'):return pyreadstat.read_sav(p)
 if suffix.endswith('.csv'):return pd.read_csv(p),None
 return p,None

def fit_ols(X,y):
 b=np.linalg.lstsq(X,y,rcond=None)[0];rank=np.linalg.matrix_rank(X);df=len(y)-rank
 resid=y-X@b;variance=(resid@resid)/df;cov=np.linalg.inv(X.T@X)*variance
 return b,cov,df

def contrast(b,cov,df,c):
 val=float(c@b);se=float(np.sqrt(c@cov@c));t=val/se;p=float(2*stats.t.sf(abs(t),df))
 return dict(estimate=val,se=se,t=t,df=int(df),p_two_sided=p,ci95=[val-stats.t.ppf(.975,df)*se,val+stats.t.ppf(.975,df)*se])

results={}
# RPP69: The report's analysis plan explicitly requires all six tests to reject
# chance. The supplied audit script uses 1/3; report prints 33%. Both are checked.
d,m=load('rpp.69','error variable.sav');rows=[]
for name in ['Prcam','Prcaf','Prafm','Praff','Prasm','Prasf']:
 assert m.variable_value_labels[name]=={1.0:'Correct',2.0:'Error'}
 v=d[name].dropna();assert set(v)<=set([1,2]);k=int(v.eq(1).sum());n=len(v)
 test=stats.binomtest(k,n,p=1/3,alternative='two-sided')
 # Independent enumeration of R-style two-sided exact probabilities.
 probs=stats.binom.pmf(np.arange(n+1),n,1/3);p_manual=float(probs[probs<=probs[k]*(1+1e-7)].sum())
 assert np.isclose(p_manual,test.pvalue,rtol=1e-10,atol=1e-20)
 rows.append(dict(target=name,correct=k,n_nonmissing=n,accuracy=k/n,chance=1/3,p_two_sided=float(test.pvalue),p_independent_enumeration=p_manual,p_using_report_rounded_chance_033=float(stats.binomtest(k,n,.33).pvalue)))
pd.DataFrame(rows).to_csv(OUT/'rpp69_six_binomial_tests.csv',index=False)
results['rpp.69']=dict(revised_outcome='successful',display_outcome='criterion-positive',input_rows=len(d),valid_target_trials=sum(r['n_nonmissing'] for r in rows),statistical_rule='Every one of six two-sided exact binomial tests must have p<.05 and recognition above chance',all_six_significant=all(r['p_two_sided']<.05 for r in rows),max_p=max(r['p_two_sided'] for r in rows),all_six_survive_bonferroni=all(r['p_two_sided']<.05/6 for r in rows),counts_match_report_rounding=True,source_report='https://osf.io/download/9uqxr/',source_report_locator='Analysis Plan, paragraph beginning We planned to run six unique binomial tests; Results, recognition percentages; Summary of Replication Attempt',limitations='The raw file has 333 rows, the report states 330 participants, and 324 nonmissing selected-target responses enter the six tests. Do not report frozen p=1e-6 as an exact pooled p. This result says nothing about secondary gender/intensity effects or untested cultures.')
assert results['rpp.69']['all_six_significant']
selected=d[d[['Prcam','Prcaf','Prafm','Praff','Prasm','Prasf']].notna().any(axis=1)]
results['rpp.69']['data_integrity_caveat']='324 distinct ResponseID records; six site-plus-participant-number pairs repeat across different target conditions. No exact duplicate rows. The public audit retains these records; participant-number uniqueness is not certified.'
results['rpp.69']['duplicate_code_sensitivity']=[]
for keep in ['first','last',False]:
 dd=selected.drop_duplicates(['CollectionSite','ParticipantNum'],keep=keep)
 ps=[float(stats.binomtest(int(dd[k].eq(1).sum()),int(dd[k].notna().sum()),1/3).pvalue) for k in ['Prcam','Prcaf','Prafm','Praff','Prasm','Prasf']]
 results['rpp.69']['duplicate_code_sensitivity'].append({'keep':keep,'n_records':len(dd),'max_p':max(ps),'all_six_p_below_005':all(p<.05 for p in ps)})
 assert all(p<.05 for p in ps)

# RPP52: equally spaced three-story linear trend interaction equals the
# between-condition contrast of within-person Story3 minus Story1 scores.
d,m=load('rpp.52','Affective_Incoherence_LIWC_results.sav')
assert m.variable_value_labels['AffCoh']=={1.0:'Coherent',2.0:'Incoherent'},m.variable_value_labels['AffCoh']
x=d[['AffCoh','cause.1.00','cause.2.00','cause.3.00']].dropna();linear=x['cause.3.00']-x['cause.1.00']
a=linear[x.AffCoh.eq(1)];b=linear[x.AffCoh.eq(2)];t=stats.ttest_ind(a,b,equal_var=True)
X=np.c_[np.ones(len(x)),x.AffCoh.eq(1).astype(int)];bb,cov,df=fit_ols(X,linear.to_numpy());cc=contrast(bb,cov,df,np.array([0,1]))
assert np.isclose(cc['t'],t.statistic) and np.isclose(cc['p_two_sided'],t.pvalue)
results['rpp.52']=dict(revised_outcome='failed',display_outcome='criterion-negative',statistical_rule='Two-condition difference in the equally spaced linear trend across three causal-word percentages; nominal p<.05 in original direction',n=len(x),n_coherent=len(a),n_incoherent=len(b),contrast=cc,F=float(t.statistic**2),df1=1,df2=int(t.df),means=x.groupby('AffCoh').mean().to_dict('index'),original_direction='Coherent condition has a larger increase than incoherent condition',source_original='https://pmc.ncbi.nlm.nih.gov/articles/PMC2365308/',source_original_locator='Study 5, Linguistic Analyses, causal words paragraph (original linear interaction F(1,131)=5.79)',source_report='https://osf.io/download/wcgx5/',limitations='This newly reconstructed linear contrast matches the frozen p=.321966 but differs from the omnibus interaction printed in the replication report and selected by its audit script. It repairs selected-statistic provenance; it is not a newly conducted experiment.')
assert np.isclose(float(t.pvalue),.3219664356580915)
# RPP93: declared simple effect at low self-esteem with approach priming.
d,m=load('rpp.93','Murray et al replication data set COS 3.20.15 FINAL.sav')
assert m.variable_value_labels['FaultCond']=={-1.0:'Control',1.0:'Rejection'}
assert m.variable_value_labels['PrimingCond']=={0.0:'Control',1.0:'Approach'}
cols=['P1RSE.Centered','FaultCond','PrimingCond','RSExFault','RSExPrime','FaultxPrime','RSExPrimexFault']
x=d[cols+['P1PerceivedDisregard']].dropna();X=np.c_[np.ones(len(x)),x[cols]];y=x.P1PerceivedDisregard.to_numpy();b,cov,df=fit_ols(X,y)
assert np.allclose(x.RSExFault,x['P1RSE.Centered']*x.FaultCond)
assert np.allclose(x.RSExPrime,x['P1RSE.Centered']*x.PrimingCond)
assert np.allclose(x.FaultxPrime,x.FaultCond*x.PrimingCond)
assert np.allclose(x.RSExPrimexFault,x['P1RSE.Centered']*x.FaultCond*x.PrimingCond)
full_sd=float(d.P1RSEmean.std());variants=[]
for label,sd in [('full_available_selfesteem_sample_sd',full_sd),('regression_complete_case_sd',float(x['P1RSE.Centered'].std())),('report_rounded_sd',.95)]:
 # At S=-sd and Prime=1, slope for effects-coded Fault is bF-sd*bSF+bFP-sd*bSFP.
 c=np.array([0,0,1,0,-sd,0,1,-sd]);cc=contrast(b,cov,df,c)
 # Independent reparameterization sets low self-esteem and approach as origins.
 s=x['P1RSE.Centered'].to_numpy()+sd;f=x.FaultCond.to_numpy();p=x.PrimingCond.to_numpy()-1
 XX=np.column_stack([np.ones(len(x)),s,f,p,s*f,s*p,f*p,s*f*p]);b2,cov2,df2=fit_ols(XX,y);check=contrast(b2,cov2,df2,np.eye(8)[2])
 assert np.allclose([cc['estimate'],cc['se'],cc['p_two_sided']],[check['estimate'],check['se'],check['p_two_sided']],rtol=1e-12)
 variants.append(dict(sd_definition=label,sd=sd,half_difference=cc,rejection_minus_control_difference=2*cc['estimate'],reparameterization_check_passed=True))
results['rpp.93']=dict(source_original='https://doi.org/10.1037/0022-3514.94.3.429',source_original_access='https://www.researchgate.net/publication/5568464_Balancing_Connectedness_and_Self-Protection_Goals_in_Close_Relationships_A_Levels-of-Processing_Perspective_on_Risk_Regulation',source_original_locator='Experiment 8, Perceptions of the Partner’s Disregard, journal p.452; hierarchical regression specification pp.451-452',revised_outcome='failed',display_outcome='criterion-negative',statistical_rule='Positive simple effect of partner criticism at one SD below mean self-esteem with approach prime, tested in the full factorial OLS model',n_model=len(x),df_residual=df,full_sample_selfesteem_n=int(d.P1RSEmean.notna().sum()),simple_effect_variants=variants,archived_distinct_threeway_interaction=contrast(b,cov,df,np.eye(8)[7]),source_report='https://osf.io/download/3hndq/',source_report_locator='Analysis Plan; Results statement low self-esteem M=5.65 SD=.95; Table 1',limitations='Report target is a simple effect; frozen p=.264930 is a different three-way interaction. Neither supports the positive original target. This audit reconstructs the declared target from public data and preserves its distinction from the archived statistic. Original article target corroborated in authors’ publicly posted full text, Experiment 8, Perceptions of the Partner’s Disregard (journal p.452): conditional original t(83)=3.05, p<.01.')
# RPP19: faithfully reproduce the published audit, but do NOT equate its grouping
# contrast to the original within-person relevant-list-length target.
d,m=load('rpp.19','Proportion correct wide 2.sav')
d['overall_accuracy']=d[['correct','intrusion','new']].mean(axis=1)
z=stats.ttest_ind(*[g.overall_accuracy for _,g in d.groupby('listtype')],equal_var=True)
raw,_=load('rpp.19','dat2.csv')
assert raw[raw.condition.eq('new')].probecol.eq('white').all()
agg=raw.groupby(['subject','condition']).correct_n.mean().unstack().reset_index()
merged=d.merge(agg,on='subject',suffixes=('_wide','_trial'),validate='one_to_one')
for k in ['correct','intrusion','new']:assert np.allclose(merged[k+'_wide'],merged[k+'_trial'])
results['rpp.19']=dict(revised_outcome='ambiguous',display_outcome='unresolved',n=len(d),audit_F=float(z.statistic**2),audit_p=float(z.pvalue),df1=1,df2=int(z.df),grouping_variable='Stored listtype labels (short-long versus long-short), without verified experimental assignment',archived_trial_rows=len(raw),trials_per_subject=raw.groupby('subject').size().unique().tolist(),new_probe_cue_field_available=False,source_original='https://www.psychologie.uzh.ch/dam/jcr%3Affffffff-bd53-4653-ffff-ffffa029726c/Oberauer_2008_JEPLMC.pdf',source_original_locator='Journal pp.451-453: relevant-list length changes within participants; new-probe accuracy F(1,31)=14.2; overall F(1,31)=18.7; grouping order distinct',source_report='https://osf.io/download/n32zj/',limitations='Public audit reproduces p=.070883 as a between-stored-label comparison. Subsequent code/data review found that the labels do not represent the recorded stimulus-order pattern; no verified experimental presentation-order effect is claimed. Both the frozen new-probe target and report overall target concern relevant-list length, a different within-person variable. Wide data collapse relevant-list lengths. Trial file has no explicit frame/cue color for new probes: all new probecol values are white. It is not justified to label the new-probe column group contrast as a repair of the original target. Stays excluded pending appropriate source data or design reconstruction.')
result=dict(audited_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),audit_type='AI-assisted reproducible primary-data statistical audit; not human annotation',upstream_analysis_code_executed=False,packages={p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','pyreadstat']},input_sources=inputs,results=results)
(OUT/'recomputed_targets_v2_3.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda x: x.item() if isinstance(x,np.generic) else x))
print(json.dumps({k:{f:v[f] for f in ['revised_outcome','display_outcome']} for k,v in results.items()},indent=2))
