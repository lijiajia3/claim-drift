"""Retrieve only five named public research datasets; verify fixed byte hashes.

No local manuscript, citation context or human rating is transmitted. The
manifest contains the public OSF download links previously audited for the four
source-target calculations. Participant-level public inputs are not redistributed
inside this checkpoint.
"""
from pathlib import Path
import urllib.request,json,hashlib,concurrent.futures
ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'ambiguous_data/manifest.json').read_text())
def fetch(r):
 p=(ROOT/r['local_path']).resolve()
 assert p.is_relative_to(ROOT/'ambiguous_data')
 if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']:return {'file':r['name'],'status':'verified_existing'}
 assert r['url'].startswith('https://osf.io/download/')
 with urllib.request.urlopen(r['url'],timeout=90) as f:b=f.read()
 actual=hashlib.sha256(b).hexdigest()
 if actual!=r['sha256']:raise ValueError(f'Public source hash changed for {r["name"]}; stop and reconcile source version')
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 return {'file':r['name'],'status':'downloaded_and_hash_verified'}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:print(json.dumps(list(pool.map(fetch,rows)),indent=2))
