# RPP19 protocol and logging follow up

The additional public material strengthens the unresolved classification. It does not support a new positive or negative replication label, and it changes none of the 105 included papers or numerical outcomes.

## New evidence

The public experiment archive is Replication_Psychopy_Experiment_v4.1.zip, obtained from https://osf.io/download/vxtrq/. It was read as source text; the experiment was never executed.

- Lines 70–74 of Replication_Experiment_v4.1.py select short–long or long–short order using the first character of the participant code
- Every participant ID in the available transformed trial file starts with 1, giving long–short under that rule
- Independently of the ID rule, the saved word-color/probe-position pattern is red at positions 0–3 and blue at positions 4–5 for all 21 participants. That is the long–short presentation order
- The analysis file nevertheless labels 10 of those participants short–long. Those labels are not reflected in the saved stimulus colors
- For new probes, lines 212–223 generate a fresh random red/blue frame cue, set TrialWordColor to white and ProbeNum to 7
- The header at lines 85–91 and CSV write at lines 263–264 save TrialWordColor, but omit the random cue, NewNum and Frame.lineColor. No explicit random seed/state is recorded in the supplied program

Thus the cue that identifies within-person relevant-list length on new-probe trials is genuinely absent from the supplied output schema. A trial-number, participant-parity or saved-white-color recoding would not be a source-supported reconstruction of that cue.

## Protocol comparison

The document labeled Pre-data collection report, https://osf.io/download/xuft8/, has a printed date of 19 September 2014. That label/date alone does not verify prospective registration. It names serial-position curves as its primary effect and lists other effects as secondary (paragraph 34 in the extracted document). Its analysis section distinguishes list length from presentation-order group (paragraphs 49–54). The post-data report names the overall list-length effect for meta-analysis, while the frozen source description/statistic names new-probe accuracy. These are separate choices and must not be conflated.

The pre-data report describes two sessions with eight blocks of 32 trials each. The supplied program contains one eight-by-32 run, and dat2.csv contains 256 rows for each participant. The transformed file omits the datetime field written by the supplied raw schema and the program’s four practice trials, so it is a transformed main-trial export rather than a complete raw log. Running the program twice could in principle produce two sessions, but no second set of trial records is available here. This evidence does not establish which sessions or exports are represented in dat2.csv.

## Limits and decision

The supplied source version and transformed trial file support the consistency checks above. They do not prove which code version every participant actually ran, establish participant identities or support any claim about misconduct. The extra evidence is sufficient to reject a silent recoding of the missing within-person cue. RPP19 stays outside the source-criterion-complete comparison.

The existing p=.0708827 remains reproducible as a between-label comparison of each participant’s equal-weight mean accuracy across correct, intrusion and new probes. Given the additional order-label inconsistency, it should not be described as a verified experimental presentation-order effect, much less as the original within-person list-length effect.

Run verify_protocol_logging.py from the source workspace to reproduce the diagnostics. It reads source text and public data without executing third-party experiment code. File hashes and exact locators are in protocol_logging_audit.json. The subject-level consistency table is for local audit; the consequential result is the aggregate 10-label inconsistency among 21 records.
