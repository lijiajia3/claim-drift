"""Read-only protocol/data consistency diagnostics. Never executes supplied code."""
from pathlib import Path
import pandas as pd,json,hashlib
ROOT=Path(__file__).resolve().parent;SRC=ROOT.parent
code=ROOT/'experiment_files/Replication_Psychopy_Experiment/Replication_Experiment_v4.1.py'
trial=SRC/'ambiguous_data/rpp.19.r2zcn_dat2.csv';s=code.read_text();d=pd.read_csv(trial)
assert "if int(Subject[0]) % 2 == 0:" in s
assert "NewNum = random.randrange(2)" in s
assert "TrialWordColor = 'white'" in s
saved_line=next(l for l in s.splitlines() if l.strip().startswith("DataFile.write('%s,%s"))
assert 'NewNum' not in saved_line and 'Frame.lineColor' not in saved_line
header=next(l for l in s.splitlines() if "DataFile.write('datetime" in l)
assert 'frame' not in header.lower() and 'newnum' not in header.lower()
assert 'random.seed' not in s
rows=[]
for sub,g in d[d.condition.ne('new')].groupby('subject'):
 red=sorted(g.loc[g.probecol.eq('red'),'probenum'].unique().tolist());blue=sorted(g.loc[g.probecol.eq('blue'),'probenum'].unique().tolist())
 actual='long-short' if red==[0,1,2,3] and blue==[4,5] else 'short-long' if red==[0,1] and blue==[2,3,4,5] else 'other'
 rows.append(dict(subject=int(sub),archive_listtype=g.listtype.iloc[0],order_inferred_from_saved_word_colors=actual,order_from_supplied_first_digit_rule='short-long' if int(str(sub)[0])%2==0 else 'long-short',red_probenum=red,blue_probenum=blue))
r=pd.DataFrame(rows)
assert len(r)==21 and r.order_inferred_from_saved_word_colors.eq('long-short').all()
assert r.order_from_supplied_first_digit_rule.eq(r.order_inferred_from_saved_word_colors).all()
assert int(r.archive_listtype.ne(r.order_inferred_from_saved_word_colors).sum())==10
assert d[d.condition.eq('new')].probecol.eq('white').all()
assert d.groupby('subject').size().eq(256).all()
out=dict(status='Unresolved classification retained; no numerical cohort change',third_party_experiment_code_executed=False,n_subjects=21,n_stimulus_order_patterns=1,inferred_order='long-short',n_archive_order_labels_inconsistent_with_saved_word_colors=10,unlogged_random_cue=True,logged_random_seed_or_state=False,new_probe_rows=int(d.condition.eq('new').sum()),new_probe_probecol_values=sorted(d[d.condition.eq('new')].probecol.unique().tolist()),trials_per_subject=256,report_described_trials_per_subject=512,code_locators={'order_rule':'lines70-74','output_header':'lines85-91','stimulus_colors':'lines186-194','cue_generation_new_probe':'lines212-223','actual_csv_write':'lines263-264','one_run_trial_loop':'lines293-306'},source_urls={'experiment_archive':'https://osf.io/download/vxtrq/','predata_report':'https://osf.io/download/xuft8/','trial_data':'https://osf.io/download/7yvhu/'},sha256={'supplied_code':hashlib.sha256(code.read_bytes()).hexdigest(),'trial_csv':hashlib.sha256(trial.read_bytes()).hexdigest()},inference_limit='The archived code and transformed trial file agree on one order, but this is not proof of which source-code version every participant actually ran. No participant-level identity or misconduct conclusion is drawn. The missing cue cannot be justified by a deterministic mapping in these supplied records.')
(ROOT/'protocol_logging_audit.json').write_text(json.dumps(out,indent=2));r.to_csv(ROOT/'order_consistency.csv',index=False);print(json.dumps(out,indent=2))
