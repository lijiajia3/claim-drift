"""Download public RPP19 materials for read-only inspection; never execute them."""
from pathlib import Path
import urllib.request,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
for r in json.loads((ROOT/'source_manifest.json').read_text()):
 p=ROOT/r['file'];assert p.resolve().is_relative_to(ROOT)
 b=p.read_bytes() if p.exists() else urllib.request.urlopen(r['url'],timeout=90).read()
 assert hashlib.sha256(b).hexdigest()==r['sha256'],r['file'];p.write_bytes(b)
with zipfile.ZipFile(ROOT/'experiment_v4_1.zip') as z:
 name='Replication_Psychopy_Experiment/Replication_Experiment_v4.1.py'
 p=ROOT/'experiment_files'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
print('Public files verified and supplied source extracted for read-only inspection. No experiment code executed.')
