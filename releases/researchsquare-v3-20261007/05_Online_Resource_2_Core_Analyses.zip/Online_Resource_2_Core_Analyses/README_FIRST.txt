ONLINE RESOURCE 2  CORE NUMERICAL AND SOURCE ANALYSES
Companion manuscript: Measurement choices in longitudinal citation language comparisons around replication projects

01_score_and_literal_replay contains the frozen clean 105-source score inputs, complete numerical results, aggregate measurement diagnostics and all literal-family tables, including the separate 106-source Staunton sensitivity. Its run_all.sh is an offline numerical replay.
02_selection_decomposition contains the standalone aggregate-input decomposition, complete influence/time/support checks and independent computational verification. Its run_all.sh needs no new model calls or human ratings.
03_source_criterion_clarifications preserves the RPP73/RPP154 selected-criterion clarification and public-source replay code. Downloaded participant-level primary-study data are not bundled.
04_source_ledgers contains source reconstruction, attrition, date metadata, ambiguous-target results and public-source replay instructions, including the RPP19 restriction.

The package does not contain raw citation sentences, individual human ratings, rater identities, private annotation-export metadata, blank recruitment tasks or participant-level primary-study data. Historical blank rating-task preparation is an author-only archive and is not part of this supplement. Aggregate historical measurement summaries are retained; recomputing these from original ratings requires the original author-held archive and is distinct from the source-free score/literal arithmetic replay.

Earlier README language and historical feasibility comments describe their checkpoint date. The completed bounded external article-level linkage audit is supplied separately as Online Resource 4; it does not establish sentence-level semantic validation. Retention benchmark inputs and code are in Online Resource 3. No new public repository release, human validation or prospective preregistration is claimed.

Each subpackage preserves scientific inputs and inherited checksums unchanged. The outer SUBMISSION_MANIFEST.json hashes this curated derivative. Source code and third-party provenance retain their stated terms. Outputs from new reproduction runs should be written to copies or new output directories.
