RPP73 and RPP154 source clarification
Scientometrics numerical and criterion supplement
5 October 2026

The existing 105-source analysis is retained as a conservative baseline, with
48 criterion-positive and 57 criterion-negative sources. This retention is not
a newly claimed prospective exclusion rule.

A separate 106-source sensitivity adds RPP73 using its archived selected
Staunton contrast: predicted-direction nominal significance in a Pearson
chi-square goodness-of-fit test against Democratic/Republican voter
proportions .30/.70. This sensitivity has 49 positive and 57 negative sources.
It does not resolve a unique source-wide aggregation rule for RPP73.

RPP154 has reproducible numerical results but conflicting historical interval
criteria. Its nominal primary p-value is not applicable. The separate
criterion-specific outcomes are retained instead of forcing one binary label.

Read SCIENTIFIC_DECISION_NOTE.txt for the evidence, interpretations and limits.
The derived directory contains numerical tables; source_status_addendum.csv
separates statistical recovery, criterion status and cohort inclusion.
public_source_download_manifest.json lists public primary sources and their
verified hashes. Source articles, reports, correspondence and source full
texts are not redistributed in this package.

Reproduction

Python 3 with numpy, pandas and scipy is sufficient for the default offline
calculation from the included numerical summaries:

  python reproduce_results.py
  python -m unittest -v test_criteria.py

For optional verification against separately obtained public primary datasets,
also install pyreadstat, openpyxl and xlrd. The following explicit command
downloads only three public datasets from the supplied source manifest:

  python reproduce_results.py --download --input-dir public_inputs

Alternatively, place the three datasets at the filenames listed in the
manifest and use --verify-primary --input-dir public_inputs. The script checks
all three source hashes and compares the primary counts and correlations with
the included numerical summaries. It executes no downloaded analysis scripts.

derived_results.json contains the expected numerical result. validation.json
records successful offline calculation, criterion tests and comparison with
the three primary datasets. checksums.sha256 covers the files in this package.
These checks establish calculation fidelity; they do not convert an ambiguous
historical criterion into a unique outcome or establish human annotation.
