"""Reproduce the RPP73/RPP154 addendum from numerical summaries.

Default: fully offline, uses derived CSV inputs included in this bundle.
Optional: --verify-primary --input-dir PATH checks separately obtained public
datasets against their source hashes and numerical summaries.
Optional: --download downloads only three public datasets in the manifest.
No downloaded analysis scripts are executed.
"""
from pathlib import Path
import argparse, json, hashlib, urllib.request
import numpy as np
import pandas as pd
from scipy import stats

ROOT=Path(__file__).resolve().parent

def mean_r(values):
    return float(np.tanh(np.mean(np.arctanh(values))))

def inside(value, bounds):
    return bool(bounds[0]<=value<=bounds[1])

def conjunction(a,b):
    if a is False or b is False: return False
    if a is None or b is None: return None
    return True

def disjunction(a,b):
    if a is True or b is True: return True
    if a is None or b is None: return None
    return False

def status(value, applicable=True):
    if not applicable:return 'not_applicable'
    return {True:'met',False:'not_met',None:'unresolved'}[value]

def derive_results():
    sites=pd.read_csv(ROOT/'derived/rpp73_site_statistics.csv')
    decisions={};numeric={}
    for row in sites.to_dict('records'):
        o=np.array([row['democratic_n'],row['republican_n']])
        q=row['reported_voter_dem_percent']/(row['reported_voter_dem_percent']+row['reported_voter_rep_percent'])
        e=o.sum()*np.array([q,1-q]);chi,p=stats.chisquare(o,e)
        sign=1 if row['predicted_majority_party']=='Democratic' else -1
        direction=sign*(o[0]/o.sum()-q)>0
        assert np.isclose(p,row['p_pearson'],atol=1e-14)
        assert np.isclose(chi,row['chi_square'],atol=1e-13)
        numeric[row['site']]={'chi_square':float(chi),'pearson_p':float(p),'exact_binomial_p':float(stats.binomtest(int(o[0]),int(o.sum()),q).pvalue)}
        decisions[row['site']]=bool(p<.05 and direction)
    correlations=pd.read_csv(ROOT/'derived/rpp154_correlations.csv')
    partials=pd.read_csv(ROOT/'derived/rpp154_partial_correlations.csv')
    expected=pd.read_csv(ROOT/'derived/rpp154_construct_averages.csv').set_index('construct')
    averages={}
    for construct,c in correlations.groupby('construct'):
        p=partials[partials.construct.eq(construct)]
        raw=mean_r(c.r);partial=mean_r(p.r_partial)
        assert np.isclose(raw,expected.loc[construct,'mean_unadjusted_r'],atol=1e-14)
        assert np.isclose(partial,expected.loc[construct,'mean_partial_r'],atol=1e-14)
        averages[construct]={'unadjusted_mean_r':raw,'partial_mean_r':partial}
    selfmean=averages['NEO_C_self']
    unadjusted_ok=inside(selfmean['unadjusted_mean_r'],[-.52,-.33])
    partial_ok=inside(selfmean['partial_mean_r'],[-.58,-.02])
    original=pd.read_csv(ROOT/'derived/rpp154_original_self_correlations.csv')
    return {
        'primary_cohort':{'n':105,'criterion_positive':48,'criterion_negative':57,'interpretation':'Retained conservative baseline; no newly prospective exclusion rule is claimed.'},
        'selected_contrast_sensitivity':{'n':106,'criterion_positive':49,'criterion_negative':57,'definition':'Add RPP73 as the archived selected Staunton contrast, with predicted-direction nominal Pearson significance; source-wide aggregation remains unresolved.'},
        'rpp73':{'statistics':numeric,'selected_staunton':status(decisions['Staunton']),
                 'initially_named_pair':status(conjunction(decisions['Charlottesville'],decisions['Staunton'])),
                 'all_four_conjunction':status(all(decisions.values())),'sourcewide_rule':'unresolved'},
        'rpp154':{'means':averages,'original_self_unadjusted_mean':mean_r(original.r),
                  'unadjusted_interval':status(unadjusted_ok),'partial_interval':status(partial_ok),
                  'later_report_and_rule':status(conjunction(unadjusted_ok,partial_ok)),
                  'earlier_or_rule_matched_partial_interpretation':status(disjunction(partial_ok,None)),
                  'earlier_literal_minus043_or_overlap':status(disjunction(inside(selfmean['partial_mean_r'],[-.52,-.33]),None)),
                  'unique_historical_rule':'unresolved','primary_nominal_p':status(None,applicable=False)}
    }

def public_inputs(folder, download=False):
    needed=['rpp73_counts.xlsx','rpp154_final.sav','rpp154_original.xls']
    manifest=json.loads((ROOT/'public_source_download_manifest.json').read_text())
    records={x['resource_id']:x for x in manifest}
    folder.mkdir(parents=True,exist_ok=True)
    paths={}
    for name in needed:
        item=records[name];p=folder/name
        if download and not p.exists():
            with urllib.request.urlopen(item['url'],timeout=120) as response:
                content=response.read()
            if hashlib.sha256(content).hexdigest()!=item['sha256']:
                raise ValueError('Public source has changed; do not substitute it silently: '+name)
            p.write_bytes(content)
        if not p.exists():raise FileNotFoundError('Obtain the public dataset listed in the manifest: '+name)
        if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
            raise ValueError('Source hash mismatch: '+name)
        paths[name]=p
    return paths

def verify_primary(paths):
    import pyreadstat
    w=pd.read_excel(paths['rpp73_counts.xlsx'],header=None)
    summaries=pd.read_csv(ROOT/'derived/rpp73_site_statistics.csv').set_index('site')
    for col,name in [(1,'Albemarle'),(5,'Charlottesville'),(9,'Waynesboro'),(13,'Staunton')]:
        assert w.iloc[17,col]==name
        assert int(w.iloc[20,col+1])==summaries.loc[name,'democratic_n']
        assert int(w.iloc[20,col+3])==summaries.loc[name,'republican_n']
    d,_=pyreadstat.read_sav(paths['rpp154_final.sav'])
    cols=['life_expectancy','GDP_percapita','postal_speed','clock_accuracy','walking_speed','PNC','NEO_C_self','NEO_C_peer_means']
    lw=d[cols].dropna();assert len(lw)==9
    correlations=pd.read_csv(ROOT/'derived/rpp154_correlations.csv')
    partials=pd.read_csv(ROOT/'derived/rpp154_partial_correlations.csv')
    C=d[cols].corr();L=lw.corr()
    for row in correlations.to_dict('records'):
        frame=d if row['deletion']=='pairwise' else lw
        cc=frame[[row['construct'],row['criterion']]].dropna()
        assert len(cc)==row['n']
        r=stats.pearsonr(cc.iloc[:,0],cc.iloc[:,1]).statistic
        assert np.isclose(r,row['r'],atol=1e-13)
    for row in partials.to_dict('records'):
        matrix=C if row['deletion']=='pairwise_matrix' else L
        x,y,z=row['construct'],row['criterion'],'GDP_percapita'
        r=(matrix.loc[x,y]-matrix.loc[x,z]*matrix.loc[y,z])/np.sqrt((1-matrix.loc[x,z]**2)*(1-matrix.loc[y,z]**2))
        assert np.isclose(r,row['r_partial'],atol=1e-13)
    orig=pd.read_excel(paths['rpp154_original.xls'],header=1).iloc[:,:11]
    fields=[c for c in orig if c not in ['COUNTRY','Unnamed: 6']]
    ow=orig[fields].dropna();assert len(ow)==10
    for row in pd.read_csv(ROOT/'derived/rpp154_original_self_correlations.csv').to_dict('records'):
        frame=orig if row['deletion']=='pairwise' else ow
        cc=frame[['Self NEO-PI-R',row['criterion']]].dropna()
        assert len(cc)==row['n']
        assert np.isclose(stats.pearsonr(cc.iloc[:,0],cc.iloc[:,1]).statistic,row['r'],atol=1e-13)
    return {'source_hashes_checked':3,'count_and_correlation_comparisons':'passed'}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--input-dir',type=Path,default=Path('public_inputs'))
    parser.add_argument('--download',action='store_true',help='Download only the three public datasets needed for primary verification')
    parser.add_argument('--verify-primary',action='store_true')
    args=parser.parse_args()
    result=derive_results()
    if args.download or args.verify_primary:
        result['primary_verification']=verify_primary(public_inputs(args.input_dir,args.download))
    print(json.dumps(result,indent=2))
