import unittest
import reproduce_results as r

class Criteria(unittest.TestCase):
    def test_missing_is_unresolved(self):self.assertEqual(r.status(None),'unresolved')
    def test_inapplicable_is_distinct(self):self.assertEqual(r.status(None,False),'not_applicable')
    def test_negative_and_missing(self):self.assertIs(r.conjunction(False,None),False)
    def test_positive_and_missing(self):self.assertIsNone(r.conjunction(True,None))
    def test_positive_or_missing(self):self.assertIs(r.disjunction(True,None),True)
    def test_negative_or_missing(self):self.assertIsNone(r.disjunction(False,None))
    def test_unadjusted_outside(self):self.assertFalse(r.inside(-.106296,[-.52,-.33]))
    def test_partial_inside(self):self.assertTrue(r.inside(-.212127,[-.58,-.02]))
    def test_derived_results(self):
        d=r.derive_results()
        self.assertEqual(d['primary_cohort']['n'],105)
        self.assertEqual(d['selected_contrast_sensitivity']['n'],106)
        self.assertEqual(d['rpp73']['selected_staunton'],'met')
        self.assertEqual(d['rpp73']['all_four_conjunction'],'not_met')
        self.assertEqual(d['rpp154']['later_report_and_rule'],'not_met')
        self.assertEqual(d['rpp154']['primary_nominal_p'],'not_applicable')

if __name__=='__main__':unittest.main(verbosity=2)
