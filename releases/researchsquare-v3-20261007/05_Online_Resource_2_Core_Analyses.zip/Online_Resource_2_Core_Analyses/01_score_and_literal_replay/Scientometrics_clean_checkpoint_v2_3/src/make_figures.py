#!/usr/bin/env python3
"""Render deterministic publication-style figures from machine-readable outputs."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/scientometrics_matplotlib')
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from scipy import stats
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs';FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titlesize':11,'axes.titleweight':'bold','pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'scientometrics_source_repair','savefig.dpi':300})
COLORS={'negative':'#D55E00','positive':'#0072B2'}
CAPTIONS=[]

def save(fig,name,caption):
    for ext in ('png','pdf','svg'):
        metadata={'Creator':'Offline source-paper analysis'}
        if ext=='pdf':metadata.update(CreationDate=None,ModDate=None)
        if ext=='svg':metadata.update(Date=None)
        fig.savefig(FIG/f'{name}.{ext}',bbox_inches='tight',metadata=metadata)
    plt.close(fig);CAPTIONS.append({'figure':name,'caption':caption})

counts=pd.read_csv(OUT/'cohort_counts.csv');n=int(counts.n_papers.sum());positive=int(counts.n_positive_texts.sum())
fig,axes=plt.subplots(1,2,figsize=(10.4,4.2),gridspec_kw={'width_ratios':[1,1.15]})
for ax,col,title in zip(axes,['n_papers','n_event'],['A  Conservative source-paper baseline','B  Eligible for project-aligned change']):
    projects=['RPP','EERP','ML1','ML3'];x=np.arange(4)
    for offset,arm in [(-.19,'negative'),(.19,'positive')]:
        vals=[int(counts.loc[(counts.project==p)&(counts.outcome==arm),col].iloc[0]) for p in projects]
        bars=ax.bar(x+offset,vals,width=.36,color=COLORS[arm],label='Criterion-'+arm)
        ax.bar_label(bars,padding=3,fontsize=9)
    ax.set_xticks(x,projects);ax.set_ylabel('Source papers');ax.set_title(title,loc='left');ax.set_ylim(0,max(counts[col])*1.2+1)
axes[1].legend(frameon=False,loc='upper right');fig.tight_layout(w_pad=3)
save(fig,'fig01_cohort_support',f'Source-paper support by actual replication project and explicitly reconstructed criterion. Panel A includes {n} source papers under the conservative inclusion rule; panel B requires at least ten retained positive text units before and at or after the project journal-publication year. Counts are sources, not independent citing articles. Criterion labels apply to selected tests rather than all findings in each paper.')

primary=pd.read_csv(OUT/'primary_contrasts.csv');fig,axes=plt.subplots(1,3,figsize=(11.8,3.3))
for ax,m,label in zip(axes,['level','transformed_drift','event_change'],['A  Mean model-rated score','B  Transformed lifetime drift','C  Project-aligned change']):
    r=primary[primary.metric==m].iloc[0]
    ax.axvline(0,color='.55',linewidth=.8)
    ax.errorbar(r.estimate,0,xerr=[[r.estimate-r.bootstrap_ci95_low],[r.bootstrap_ci95_high-r.estimate]],fmt='o',color='#253746',capsize=4,markersize=6)
    ax.set_ylim(-.9,.9);ax.set_yticks([]);ax.set_title(label,loc='left');ax.set_xlabel('Criterion-negative − criterion-positive')
    ax.xaxis.set_major_locator(MaxNLocator(4))
    ax.text(.5,.79,f'n = {int(r.n_negative)} / {int(r.n_positive)} sources',transform=ax.transAxes,ha='center',fontsize=9)
    ax.text(.5,.20,f'{r.estimate:+.4f}\n[{r.bootstrap_ci95_low:+.4f}, {r.bootstrap_ci95_high:+.4f}]',transform=ax.transAxes,ha='center',fontsize=10,bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':2})
    ax.ticklabel_format(axis='x',style='plain',useOffset=False)
fig.tight_layout(w_pad=2.5)
save(fig,'fig02_descriptive_contrasts','Equal-source criterion-negative minus criterion-positive estimates and 95% within-outcome source-bootstrap percentile intervals (19,999 draws). Each panel uses its stated eligibility rule. Horizontal scales differ because transformed drift is not raw score change per year. Frozen language scores, text retrieval, labels and dates are treated as fixed; intervals do not include uncertainty in those inputs and do not establish a causal replication response.')

sens=pd.read_csv(OUT/'sensitivity_grid.csv')
scenarios=[('conservative_source_baseline','Conservative baseline'),('source_based_labels_all108_unresolved_archived','All 108; unresolved labels archived'),('recorded_manuscript_upload_years','Recorded manuscript-upload years'),('omit_event_year','Omit project event year'),('latest_conflicting_dates','Latest candidate text year'),('drop_conflicting_dates','Drop date-conflict texts'),('development_text_frame_only','Development text format only'),('luna_component','Luna component'),('deepseek_component','DeepSeek component'),('symmetric_3yr_excluding_event_year','Symmetric ±3 years; omit year 0'),('symmetric_5yr_excluding_event_year','Symmetric ±5 years; omit year 0'),('symmetric_8yr_excluding_event_year','Symmetric ±8 years; omit year 0'),('min_event_5','At least 5 texts per period')]
fig,ax=plt.subplots(figsize=(8.8,6.7));ys=np.arange(len(scenarios))[::-1]
plotted=sens[(sens.scenario.isin([key for key,label in scenarios]))&(sens.metric=='event_change')]
lo=float(plotted.bootstrap_ci95_low.min());hi=float(plotted.bootstrap_ci95_high.max());span=hi-lo;count_x=hi+.14*span
for y,(key,label) in zip(ys,scenarios):
    r=sens[(sens.scenario==key)&(sens.metric=='event_change')].iloc[0]
    ax.errorbar(r.estimate,y,xerr=[[r.estimate-r.bootstrap_ci95_low],[r.bootstrap_ci95_high-r.estimate]],fmt='o',color='#253746' if key=='conservative_source_baseline' else '#0072B2',capsize=2,markersize=5)
    ax.text(count_x,y,f'{int(r.n_negative)} / {int(r.n_positive)}',va='center',fontsize=8.5)
ax.axvline(0,color='.5',linewidth=.8);ax.set_yticks(ys,[label for key,label in scenarios]);ax.set_ylim(-.6,len(ys)-.2);ax.set_xlim(lo-.07*span,hi+.42*span)
ax.set_xlabel('Project-aligned change: criterion-negative minus criterion-positive');ax.set_title('Project-aligned change under fixed repair diagnostics',loc='left');ax.text(count_x,len(ys)-.50,'Sources − / +',va='bottom',fontsize=8.5);fig.tight_layout()
save(fig,'fig03_event_sensitivity','Fixed post hoc repair sensitivity grid for project-aligned changes. Points use equal source weights; bars are 95% source-bootstrap percentile intervals. Text-year alternatives diagnose deduplication rather than certify chronology. Symmetric windows exclude the event year. Eligibility and source composition differ across rows, so differences between estimates do not isolate a single causal mechanism. All-108 mechanical labels preserve unresolved cases under their archived assignments; the source-complete main row excludes unresolved criteria.')

paper=pd.read_csv(OUT/'primary_paper_estimates.csv');event=pd.read_csv(OUT/'event_paper_years.csv');fig,(ax,axn)=plt.subplots(2,1,figsize=(9.7,6.5),sharex=True,gridspec_kw={'height_ratios':[3,1]})
rows=[]
for arm in ('negative','positive'):
    means=[];lo=[];hi=[];ns=[];ts=list(range(-8,9))
    for t in ts:
        v=event.loc[(event.outcome==arm)&(event.event_time==t),'change_from_pre5_mean'].to_numpy();ns.append(len(v));means.append(v.mean() if len(v) else np.nan)
        if len(v)>=2:
            se=stats.sem(v);q=stats.t.ppf(.975,len(v)-1);lo.append(v.mean()-q*se);hi.append(v.mean()+q*se)
        else:lo.append(np.nan);hi.append(np.nan)
    means=np.array(means);ax.plot(ts,means,'o-',color=COLORS[arm],markersize=4,label='Criterion-'+arm)
    ax.fill_between(ts,lo,hi,color=COLORS[arm],alpha=.13);axn.plot(ts,ns,'o-',color=COLORS[arm],markersize=3)
    rows.extend({'outcome':arm,'event_time':t,'n_papers':n,'mean_change':m,'t_ci95_low':l,'t_ci95_high':h} for t,n,m,l,h in zip(ts,ns,means,lo,hi))
for a in (ax,axn):a.axvline(0,color='.45',linestyle='--',linewidth=.8)
ax.axhline(0,color='.65',linewidth=.8);ax.set_ylabel('Score change from each source’s pre-5-year mean');ax.set_title('Equal-source trajectories with observed support',loc='left');ax.legend(frameon=False,ncol=2,loc='lower right');axn.set_ylabel('Sources');axn.set_xlabel('Year relative to project journal publication');axn.set_xticks(range(-8,9));fig.tight_layout(h_pad=.6)
pd.DataFrame(rows).to_csv(OUT/'event_group_plot_data.csv',index=False)
save(fig,'fig04_event_trajectory','Annual source-paper means relative to each paper’s own positive-text mean in years −5 through −1. Each source has equal weight at a given year; source support varies with year and is shown below. Shading is a pointwise Student t interval over available source means (not a simultaneous band), conditional on the fixed baseline and score corpus. Both outcome groups receive project-results information; this is a descriptive trajectory, not an identified treatment-control event study.')

fig,ax=plt.subplots(figsize=(8.2,4.6));projects=['RPP','EERP','ML1','ML3'];ys=np.arange(4)[::-1]
for y,p in zip(ys,projects):
    r=sens[(sens.scenario=='only_'+p)&(sens.metric=='raw_score_slope')].iloc[0]
    if np.isfinite(r.welch_ci95_low):ax.errorbar(r.estimate,y,xerr=[[r.estimate-r.welch_ci95_low],[r.welch_ci95_high-r.estimate]],fmt='o',capsize=3,color='#0072B2')
    else:ax.plot(r.estimate,y,'o',color='#0072B2')
    ax.text(.029,y,f'{int(r.n_negative)} / {int(r.n_positive)} sources',va='center',fontsize=9)
ax.axvline(0,color='.5',linewidth=.8);ax.set_yticks(ys,projects);ax.set_xlim(-.032,.048);ax.set_ylim(-.65,3.65);ax.set_title('Project-specific lifetime slopes differ in direction',loc='left');ax.set_xlabel('Raw model-score slope per year: criterion-negative minus criterion-positive');fig.tight_layout()
save(fig,'fig05_project_slope_heterogeneity','Raw annual model-score slopes use the same adaptive bins and eligibility as the transformed lifetime drift endpoint. Points are project-specific group differences, with Welch 95% intervals and explicit group sizes. Very small project groups make resampling distributions discrete and estimates unstable. This is a post hoc heterogeneity diagnostic and is not evidence of independent project-specific causal effects.')

(FIG/'figure_captions.json').write_text(json.dumps(CAPTIONS,indent=2)+'\n');print('Rendered',len(CAPTIONS),'figures in PNG/PDF/SVG')
