#!/usr/bin/env python3
"""Validate aggregate inputs and exact reference outputs without private source files."""
from pathlib import Path
import csv,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def read(p):
 with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
cells=read(ROOT/'inputs/numeric_cells.csv');assert sum(int(r['frequency']) for r in cells)==15391
assert sum(int(r['frequency'])*int(r['assertion']) for r in cells)==8480
assert len({r['analysis_claim_id'] for r in cells})==108
for r in cells:
 if int(r['assertion']):assert float(r['certainty'])==(float(r['luna'])+float(r['deepseek']))/2
 else:assert r['certainty']==r['luna']==r['deepseek']==''
expected=json.loads((ROOT/'REFERENCE_OUTPUT_HASHES.json').read_text())
for rel,sha in expected.items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==sha,rel
result=json.loads((ROOT/'outputs/primary_results.json').read_text());assert (result['n_papers'],result['n_texts'],result['n_positive_texts'])==(105,15280,8427)
assert result['config']['event_column']=='event_year_journal'
print(f'PASS: aggregate count/score integrity and {len(expected)} exact output hashes')
