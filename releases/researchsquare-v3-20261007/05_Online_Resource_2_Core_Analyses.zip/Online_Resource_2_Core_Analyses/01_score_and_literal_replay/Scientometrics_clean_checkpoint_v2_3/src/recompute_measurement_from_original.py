#!/usr/bin/env python3
"""Recompute aggregate reliability, calibration and error interaction from author inputs.
The original archive is read locally; no text, task IDs, annotator metadata, dates of
annotation, receipt provenance or row-level labels are written to output.
"""
from pathlib import Path
import argparse,csv,json,hashlib,math,statistics
from collections import Counter,defaultdict
import numpy as np
from scipy.stats import rankdata,spearmanr

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def index(rows,key):
    d={r[key]:r for r in rows};assert len(d)==len(rows);return d

def save(p,value):
    def clean(x):
        if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
        if isinstance(x,(list,tuple)):return [clean(v) for v in x]
        if isinstance(x,np.ndarray):return clean(x.tolist())
        if isinstance(x,np.integer):return int(x)
        if isinstance(x,np.floating):x=float(x)
        if isinstance(x,float) and not math.isfinite(x):return None
        return x
    p.write_text(json.dumps(clean(value),indent=2,allow_nan=False)+'\n')

def flags(row):return '?' in row.get('note','') or '？' in row.get('note','')

def sentence_weights(clusters, reps, seed):
    """Rows 1..B resample unique sentences, preserving every within-sentence row."""
    unique=sorted(set(clusters)); idx=np.array([unique.index(c) for c in clusters])
    rng=np.random.default_rng(seed)
    w=rng.multinomial(len(unique),np.full(len(unique),1/len(unique)),size=reps)
    return np.vstack([np.ones(len(clusters)),w[:,idx]]),len(unique)

def interval(values):
    v=np.asarray(values)[1:];v=v[np.isfinite(v)]
    return {'estimate':float(values[0]),'ci95':np.quantile(v,[.025,.975]).tolist() if len(v) else None,'valid_bootstrap_replicates':len(v)}

def kappa_values(a,b,w):
    a=np.asarray(a);b=np.asarray(b); n=w.sum(axis=1)
    po=w@(a==b)/n
    pe=sum((w@(a==c)/n)*(w@(b==c)/n) for c in sorted(set(a)|set(b)))
    with np.errstate(invalid='ignore',divide='ignore'):return (po-pe)/(1-pe)

def alpha_values(units,w,metric='ordinal'):
    """General pairable-unit coincidence alpha; negative/NaN entries are missing.
    Ordinal distances use empirical pairable-value marginal frequencies anew in
    every resample. Pairable units only contribute to the coincidence matrix.
    """
    values=sorted({float(v) for u in units for v in u if v is not None and np.isfinite(v)})
    nc=len(values);ix={v:i for i,v in enumerate(values)}
    if nc<2:return np.full(len(w),np.nan)
    matrices=[]
    for u in units:
        z=[ix[float(v)] for v in u if v is not None and np.isfinite(v)]
        o=np.zeros((nc,nc))
        if len(z)>1:
            counts=np.bincount(z,minlength=nc)
            o=(np.outer(counts,counts)-np.diag(counts))/(len(z)-1)
        matrices.append(o.ravel())
    o=(w @ np.asarray(matrices)).reshape(-1,nc,nc)
    marg=o.sum(axis=2);n=marg.sum(axis=1)
    if metric=='ordinal':
        center=np.cumsum(marg,axis=1)-marg/2
        delta=(center[:,:,None]-center[:,None,:])**2
    elif metric=='nominal':delta=np.broadcast_to(1-np.eye(nc),o.shape)
    elif metric=='interval':delta=np.broadcast_to((np.array(values)[:,None]-np.array(values)[None,:])**2,o.shape)
    else:raise ValueError(metric)
    with np.errstate(invalid='ignore',divide='ignore'):
        do=(o*delta).sum(axis=(1,2))/n
        de=(marg[:,:,None]*marg[:,None,:]*delta).sum(axis=(1,2))/(n*(n-1))
        return 1-do/de

def corr_values(x,y,w):
    n=w.sum(axis=1);mx=w@x/n;my=w@y/n
    xx=w@(x*x)/n-mx*mx;yy=w@(y*y)/n-my*my;xy=w@(x*y)/n-mx*my
    with np.errstate(invalid='ignore',divide='ignore'):return xy/np.sqrt(xx*yy)

def spearman_values(x,y,w):
    # Counts over distinct score pairs produce exact tied ranks for bootstrap
    # samples, including observations drawn multiple times.
    def ranks(x):
        vals=np.unique(x);freq=np.stack([w@(x==v) for v in vals],axis=1)
        mid=np.cumsum(freq,axis=1)-(freq-1)/2
        return mid[:,np.searchsorted(vals,x)]
    rx,ry=ranks(x),ranks(y);n=w.sum(axis=1)
    mx=(w*rx).sum(axis=1)/n;my=(w*ry).sum(axis=1)/n
    dx=rx-mx[:,None];dy=ry-my[:,None]
    with np.errstate(invalid='ignore',divide='ignore'):
        return (w*dx*dy).sum(axis=1)/np.sqrt((w*dx*dx).sum(axis=1)*(w*dy*dy).sum(axis=1))

def score_metrics(rows, model, reps, seed, cluster='sentence_hash'):
    rows=[r for r in rows if r.get(model) is not None and r.get('human_mean') is not None]
    if not rows:return {'n':0}
    x=np.array([r[model] for r in rows]);y=np.array([r['human_mean'] for r in rows])
    w,nc=sentence_weights([r[cluster] for r in rows],reps,seed);n=w.sum(axis=1)
    mx=w@x/n;my=w@y/n;vx=w@(x*x)/n-mx*mx;vy=w@(y*y)/n-my*my;cov=w@(x*y)/n-mx*my
    with np.errstate(invalid='ignore',divide='ignore'):
        slope_m_h=cov/vy;intercept_m_h=mx-slope_m_h*my
        slope_h_m=cov/vx;intercept_h_m=my-slope_h_m*mx
        concordance=2*cov/(vx+vy+(mx-my)**2)
    vals={'spearman':spearman_values(x,y,w),'pearson':corr_values(x,y,w),
      'model_mean':mx,'human_mean':my,'bias_model_minus_human':mx-my,
      'mae':w@abs(x-y)/n,'rmse':np.sqrt(w@((x-y)**2)/n),
      'exact_score_agreement':w@(x==y)/n,'within_0_25':w@(abs(x-y)<=.25)/n,
      'model_on_human_slope':slope_m_h,'model_on_human_intercept':intercept_m_h,
      'human_on_model_slope':slope_h_m,'human_on_model_intercept':intercept_h_m,
      'lin_concordance_numeric_anchors':concordance}
    return {'n':len(rows),'n_clusters':nc,'cluster_variable':cluster,'n_claims':len({r['claim'] for r in rows if r.get('claim')}),'small_subgroup_interval_warning': 'Fewer than 20 selected sentences; empirical bootstrap intervals may be unstable or degenerate' if len(rows)<20 else None,**{k:interval(v) for k,v in vals.items()}}

def reliability(rows,reps,seed):
    w,nc=sentence_weights([r['sentence_hash'] for r in rows],reps,seed)
    a=[r['assert_A'] for r in rows];b=[r['assert_B'] for r in rows]
    pos=[r for r in rows if r['assert_A']==r['assert_B']==1]
    wp,np_=sentence_weights([r['sentence_hash'] for r in pos],reps,seed+1)
    vals=alpha_values([[r['certainty_A'],r['certainty_B']] for r in pos],wp)
    return {'n_assertion_presentations':len(rows),'n_assertion_unique_sentences':nc,
      'assertion_confusion_A_B':{f'{x}_{y}':sum(r['assert_A']==x and r['assert_B']==y for r in rows) for x in (0,1) for y in (0,1)},
      'assertion_raw_agreement':interval(w @ np.array([x==y for x,y in zip(a,b)])/w.sum(axis=1)),
      'cohen_kappa':interval(kappa_values(a,b,w)),
      'n_paired_positive_certainty_presentations':len(pos),'n_paired_positive_unique_sentences':np_,
      'ordinal_alpha_paired_positive':interval(vals),
      'interval_alpha_paired_positive':interval(alpha_values([[r['certainty_A'],r['certainty_B']] for r in pos],wp,'interval'))}

def main():
    a=argparse.ArgumentParser();a.add_argument('--original-archive',type=Path,required=True);a.add_argument('--out',type=Path,default=Path('measurement_recomputed'));a.add_argument('--bootstrap',type=int,default=9999);args=a.parse_args()
    root=args.original_archive.resolve();out=args.out.resolve()
    if root==out or root in out.parents:raise ValueError('Choose an output directory outside the unchanged original archive')
    out.mkdir(parents=True,exist_ok=True);ann=root/'annotation_package'
    key=index(read(ann/'batch01_recut/batch01_KEY_PI_ONLY.csv'),'task_id');ra=index(read(ann/'students/rater_A.csv'),'task_id');rb=index(read(ann/'students/rater_B.csv'),'task_id')
    core=index(read(ann/'core_6000_KEY.csv'),'id');ak=index(read(ann/'task_A_KEY_do_not_give_students.csv'),'id')
    val=index(read(root/'validation/luna_deepseek_v41_ensemble_248_scores.csv'),'task_id')
    corpus={(r['claim'],r['sentence'].strip()):r for r in read(root/'out_revision_hybrid/primary_sentences.csv')}
    ledger=index(read(Path(__file__).resolve().parents[1]/'inputs/analysis_ledger.csv'),'analysis_claim_id');rows=[]
    for task,k in key.items():
        aa,bb=ra[task],rb[task];m=core.get(k['src_id'],ak.get(k['src_id'],{}));name=m.get('claim','');claim='v3_'+name.removeprefix('v3_') if name else ''
        human=(float(aa['certainty'])+float(bb['certainty']))/2 if aa['assert']==bb['assert']=='1' else None
        linked=corpus.get((claim,k['sentence'].strip()));v=val.get(task,{});co=ledger.get(claim,{})
        rows.append({'item_type':k['item_type'],'sentence_hash':hashlib.sha256(k['sentence'].strip().encode()).hexdigest(),'claim':claim,
            'assert_A':int(aa['assert']),'assert_B':int(bb['assert']),'certainty_A':float(aa['certainty']) if aa['certainty'] else None,'certainty_B':float(bb['certainty']) if bb['certainty'] else None,
            'human_mean':human,'flagged_either_rater':flags(aa) or flags(bb),'ensemble_development':float(v['certainty']) if v else None,
            'ensemble_full_named_claim':float(linked['certainty']) if linked and linked['certainty'] else None,
            'year':int(linked['year']) if linked else None,'criterion':co.get('revised_outcome'),'included':co.get('include_primary','').lower()=='true','event_year':int(co['event_year_journal']) if co else None})
    ordinary=[r for r in rows if r['item_type']=='ordinary'];unique=[r for r in rows if r['item_type']!='duplicate'];dev=[r for r in ordinary if r['human_mean'] is not None]
    assert (len(rows),len(unique),len(ordinary),len(dev))==(368,356,330,248)
    first={}
    for r in rows:first.setdefault(r['sentence_hash'],r)
    sets={'all_368_presentations_historical':rows,'unique_356_including_26_QC':unique,'ordinary_330_primary_reliability':ordinary,'ordinary_without_question_flags':[r for r in ordinary if not r['flagged_either_rater']],'QC_26_only':[r for r in unique if r['item_type'].startswith('gold')],'first_task_order_unique_356_including_QC':list(first.values()),'first_task_order_ordinary_330':[r for r in first.values() if not r['item_type'].startswith('gold')]}
    rel={k:reliability(v,args.bootstrap,20261005+i*13) for i,(k,v) in enumerate(sets.items())};save(out/'reliability_estimates.json',rel)
    score=score_metrics(dev,'ensemble_development',args.bootstrap,20261005+103);save(out/'development_ensemble_agreement.json',score)
    values={};cells={}
    for group in ('failed','successful'):
        rr=[r for r in dev if r['included'] and r['criterion']==group and r['ensemble_full_named_claim'] is not None]
        w,nc=sentence_weights([r['claim'] for r in rr],args.bootstrap,20261005+1100+int(group=='successful'));err=np.array([r['ensemble_full_named_claim']-r['human_mean'] for r in rr])
        for period in ('pre','post'):
            mask=np.array([(r['year']<r['event_year'])==(period=='pre') for r in rr]);values[group,period]=(w@(err*mask))/(w@mask);cells[group+'_'+period]={'n':int(mask.sum()),'mean_error':float(values[group,period][0])}
    delta=(values['failed','post']-values['failed','pre'])-(values['successful','post']-values['successful','pre'])
    save(out/'full_run_error_interaction.json',{'cells':cells,'result':interval(delta),'interpretation':'Selected-development-sample diagnostic, not an independent holdout or a correction factor'})
    print('Saved aggregate measurement estimates only')

if __name__=='__main__':main()
