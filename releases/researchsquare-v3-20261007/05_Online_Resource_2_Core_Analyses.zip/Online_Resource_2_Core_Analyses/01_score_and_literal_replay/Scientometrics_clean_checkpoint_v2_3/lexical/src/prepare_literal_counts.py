#!/usr/bin/env python3
"""Read the unchanged author archive locally; write aggregate counts only."""
import argparse,csv,hashlib,json,sys
from pathlib import Path
from collections import defaultdict,Counter
from literal_features import *

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rows):
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    base=Path(__file__).resolve().parents[1]
    a=argparse.ArgumentParser();a.add_argument('--original-archive',type=Path,required=True);a.add_argument('--cohort',type=Path,required=True);a.add_argument('--numeric',type=Path);a.add_argument('--out',type=Path,default=base/'inputs');args=a.parse_args();args.out.mkdir(exist_ok=True,parents=True)
    freeze=base/'RULES_FROZEN.json';assert digest(freeze)=='ae036d30ac94ff55d320de34f38de65e1ab56c5fb53ab7b47b636b8b08c05832'
    cohort=read(args.cohort);meta={r['analysis_claim_id']:r for r in cohort if r['include_primary'].lower()=='true'}
    assert len(meta)==105
    if args.numeric:
        nr={r['item_id']:r for r in read(args.numeric)}
    else:
        nr={}
        for path in sorted((args.original_archive/'seeds_data').glob('scored2_v3_*.jsonl')):
            name=path.stem[len('scored2_'):]
            if name not in meta:continue
            groups=defaultdict(list)
            with path.open(encoding='utf-8') as f:
                for line in f:
                    q=json.loads(line);text=(q.get('ctx') or '').strip()
                    if text:groups[text].append(q)
            for text,qs in groups.items():
                old=min(qs,key=lambda q:int(q.get('year') or 9999));iid=hashlib.sha256(f'{name}\0{text}'.encode()).hexdigest()[:24]
                nr[iid]={'year_earliest':old['year'],'year_latest':max(int(q['year']) for q in qs),'assertion':int(old.get('assert')==1)}
    original=args.original_archive/'out_revision_hybrid/primary_sentences.csv';rows=read(original)
    aggregate=defaultdict(Counter);totals=Counter();per_source=Counter();wordrows=0
    for r in rows:
        name=r['claim']
        if name not in meta:continue
        text=r['sentence'];assertion=int(r['assert']);iid=hashlib.sha256(f'{name}\0{text}'.encode()).hexdigest()[:24]
        n=nr[iid];assert int(n['year_earliest'])==int(r['year']) and int(n['assertion'])==assertion
        totals['n_texts']+=1;totals['n_positive']+=assertion;per_source[name]+=1
        totals['n_over700']+=len(text)>700;totals['n_over1200']+=len(text)>1200
        for view,limit in VIEWS.items():
            f=features(text,limit)
            key=(name,meta[name]['source_id'],int(r['year']),int(n['year_latest']),assertion,view)
            aggregate[key].update(n_texts=1,**f)
    assert totals['n_texts']==15280 and totals['n_positive']==8427 and len(per_source)==105
    for name,nn in per_source.items():assert nn==int(meta[name]['count_contexts'])
    out=[]
    for key,c in sorted(aggregate.items()):
        name,sid,year,latest,assertion,view=key
        out.append({'analysis_claim_id':name,'source_id':sid,'year':year,'latest_year':latest,'assertion':assertion,'text_view':view,**dict(c)})
    write(args.out/'literal_counts_by_source_year.csv',out)
    keep=['analysis_claim_id','source_id','project','revised_outcome','include_primary','event_year_journal','event_year_first_located_manuscript','original_paper_doi','original_paper_title','count_contexts','count_filter_positive']
    write(args.out/'source_cohort.csv',[{k:r[k] for k in keep} for r in meta.values()])
    record={'rules_sha256':digest(freeze),'cohort_filename':args.cohort.name,'cohort_sha256':digest(args.cohort),'original_primary_csv_sha256':digest(original),'numeric_snapshot_sha256':digest(args.numeric) if args.numeric else None,'counts':dict(totals),'n_source_papers':105,'n_aggregate_rows':len(out),'raw_text_written':False,'individual_human_labels_used':False,'feature_selection_after_lexical_outcome_comparisons':False,'prior_frozen_model_results_already_known':True}
    (args.out/'preparation_verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
if __name__=='__main__':main()
