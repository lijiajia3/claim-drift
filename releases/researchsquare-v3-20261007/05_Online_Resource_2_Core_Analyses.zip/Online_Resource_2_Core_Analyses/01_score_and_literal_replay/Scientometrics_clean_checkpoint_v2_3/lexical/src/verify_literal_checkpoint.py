#!/usr/bin/env python3
from pathlib import Path
import csv,json,hashlib
R=Path(__file__).resolve().parents[1]
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
assert hashlib.sha256((R/'RULES_FROZEN.json').read_bytes()).hexdigest()=='ae036d30ac94ff55d320de34f38de65e1ab56c5fb53ab7b47b636b8b08c05832'
rows=[r for r in read(R/'inputs/literal_counts_by_source_year.csv') if r['text_view']=='full']
assert sum(int(r['n_texts']) for r in rows)==15280
assert sum(int(r['n_texts'])*int(r['assertion']) for r in rows)==8427
assert len({r['analysis_claim_id'] for r in rows})==105
for feat,total in [('epistemic_adverb_tokens',87),('replication_word_tokens',304),('lowercase_modal_tokens',1557)]:
 assert sum(int(r['context_'+feat]) for r in rows)==total
 for r in rows:assert 0<=int(r['context_'+feat])<=int(r['n_texts']) and int(r['context_'+feat])<=int(r['token_'+feat])
expected=json.loads((R/'REFERENCE_OUTPUT_HASHES.json').read_text())
for rel,sha in expected.items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==sha,rel
print(f'PASS: literal count integrity, frozen rules and {len(expected)} exact output hashes')
