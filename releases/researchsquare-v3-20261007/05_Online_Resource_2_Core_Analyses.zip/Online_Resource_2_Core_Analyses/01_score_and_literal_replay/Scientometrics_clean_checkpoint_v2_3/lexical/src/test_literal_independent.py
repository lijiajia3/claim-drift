"""Synthetic-only contract audit; does not read corpus or analysis results."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parent))
from literal_features import features

class IndependentContractTests(unittest.TestCase):
    def test_invalid_apostrophe_suffix_cannot_fall_back_to_core(self):
        for text in ["possibly's2", "perhaps'foo_bar", 'probably’foo2']:
            with self.subTest(text=text):
                self.assertEqual(features(text)['token_epistemic_adverb_tokens'], 0)
    def test_invalid_apostrophe_suffix_cannot_fall_back_to_replication(self):
        for text in ["replication's2", 'replication’s_extra', "replicates'2"]:
            with self.subTest(text=text):
                self.assertEqual(features(text)['token_replication_word_tokens'], 0)
    def test_invalid_apostrophe_suffix_cannot_fall_back_to_modal(self):
        for text in ["may's2", "might'foo_bar", 'could’foo2']:
            with self.subTest(text=text):
                self.assertEqual(features(text)['token_lowercase_modal_tokens'], 0)
    def test_nonletter_numerics_not_alphabetic_denominator(self):
        self.assertEqual(features('² Ⅻ ¼')['n_tokens'], 0)
    def test_ordinary_possessive_replication_is_counted(self):
        for text in ["replication's", 'replication’s', "REPLICATION'S"]:
            with self.subTest(text=text):
                self.assertEqual(features(text)['token_replication_word_tokens'], 1)
    def test_core_possessive_not_stripped(self):
        self.assertEqual(features("possibly's perhaps’s probably's")['token_epistemic_adverb_tokens'], 0)
    def test_unicode_letters_and_ascii_digits_block_embedded_cues(self):
        self.assertEqual(features('éperhaps perhapsé 中文probably probably中文 possibly2 2possibly')['token_epistemic_adverb_tokens'], 0)
    def test_casefold_and_no_nfkc(self):
        self.assertEqual(features('POſſIBLY ｐｏｓｓｉｂｌｙ')['token_possibly'], 1)
    def test_separate_words_at_punctuation(self):
        self.assertEqual(features('(perhaps) [probably];possibly/possibly')['token_epistemic_adverb_tokens'], 4)
    def test_quotes_and_hyphens(self):
        x=features("'perhaps' non-replication nonreplication")
        self.assertEqual(x['token_perhaps'], 1)
        self.assertEqual(x['token_replication'], 1)
    def test_ascii_numeric_length_boundaries(self):
        x=features('may 1; may 1234; may 12345; 12345 may; may 1234a')
        self.assertEqual(x['excluded_may_numeric'], 2)
        self.assertEqual(x['token_may'], 3)
    def test_numeric_guard_uses_full_text_for_prefix(self):
        x=features('may 2016', 3)
        self.assertEqual(x['token_may'], 0)
        self.assertEqual(x['excluded_may_numeric'], 1)
        self.assertEqual(x['n_tokens'], 1)
    def test_possessive_prefix_not_a_new_bare_word(self):
        self.assertEqual(features("replication's", 11)['token_replication'], 0)
        self.assertEqual(features("replication's", 13)['token_replication'], 1)
    def test_unicode_character_prefix_and_complete_token(self):
        text='é'*694+' '+'perhaps'
        self.assertEqual(features(text, 700)['token_perhaps'], 0)
        self.assertEqual(features(text, 702)['token_perhaps'], 1)
    def test_model_independent_boolean_and_count(self):
        x=features('perhaps perhaps; may may; replication replication')
        self.assertEqual(x['token_epistemic_adverb_tokens'], 2)
        self.assertEqual(x['context_epistemic_adverb_tokens'], 1)
        self.assertEqual(x['token_lowercase_modal_tokens'], 2)
        self.assertEqual(x['token_replication_word_tokens'], 2)

if __name__=='__main__':
    unittest.main(verbosity=2)
