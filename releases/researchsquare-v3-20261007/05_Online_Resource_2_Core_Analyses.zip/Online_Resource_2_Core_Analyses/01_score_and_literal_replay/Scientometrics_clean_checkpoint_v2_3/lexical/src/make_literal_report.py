#!/usr/bin/env python3
"""Recipient-facing report and figures, written only from aggregate outputs."""
from pathlib import Path
import os,json
os.environ.setdefault('MPLCONFIGDIR','/tmp/scientometrics_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'outputs';F=ROOT/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','svg.hashsalt':'literal_features_v1','pdf.fonttype':42})
LABELS={'epistemic_adverb_tokens':'Three adverb tokens','replication_word_tokens':'Replication-word forms','lowercase_modal_tokens':'Lowercase modals (sensitivity)'}
def save(fig,name):
 for ext in ('png','pdf','svg'):
  meta={'Creator':'Frozen literal-token diagnostic'}
  if ext=='pdf':meta.update(CreationDate=None,ModDate=None)
  if ext=='svg':meta.update(Date=None)
  fig.savefig(F/f'{name}.{ext}',bbox_inches='tight',dpi=300,metadata=meta)
 plt.close(fig)
def pp(x):return f'{100*x:+.2f}'
def table(df,cols):
 return '| '+' | '.join(cols)+' |\n| '+' | '.join('---' for c in cols)+' |\n'+'\n'.join('| '+' | '.join(str(r[c]) for c in cols)+' |' for _,r in df.iterrows())
def main():
 raw=pd.read_csv(O/'raw_counts_all_words_and_families.csv');ret=pd.read_csv(O/'qwen_retention_by_literal_feature.csv');summ=pd.read_csv(O/'source_bootstrap_contrasts.csv');pair=pd.read_csv(O/'matched_source_filter_comparison.csv');comp=pd.read_csv(O/'matched_filter_shared_component_sensitivity.csv');config=json.loads((O/'method.json').read_text())
 rr=ret[(ret.text_view=='full')&ret.feature.isin(LABELS)].set_index('feature').loc[list(LABELS)].reset_index()
 fig,ax=plt.subplots(figsize=(8.8,3.3));ys=np.arange(len(rr))[::-1]
 for y,(_,r) in zip(ys,rr.iterrows()):
  p=r.positive_retention_fraction;ax.barh(y,p*100,color='#0072B2',height=.55);ax.barh(y,(1-p)*100,left=p*100,color='#B8BDC6',height=.55)
  ax.text(p*50,y,str(int(r.qwen_positive_hit_contexts)),color='white',ha='center',va='center');ax.text(p*100+(1-p)*50,y,str(int(r.qwen_negative_hit_contexts)),ha='center',va='center');ax.text(103,y,f'n={int(r.all_hit_contexts)}',va='center')
 ax.axvline(8427/15280*100,color='.3',linestyle=':',linewidth=1);ax.set_xlim(0,115);ax.set_xticks([0,25,50,75,100]);ax.set_yticks(ys,[LABELS[x] for x in rr.feature]);ax.set_xlabel('Share of feature-containing text units (%)');ax.set_title('Literal features and Qwen-filter retention',loc='left',fontsize=11,fontweight='bold');fig.tight_layout(rect=[0,.12,1,1]);fig.legend(handles=[Patch(color='#0072B2',label='Qwen-positive'),Patch(color='#B8BDC6',label='Qwen-negative'),Line2D([0],[0],color='.3',linestyle=':',label='All-text positive fraction (55.2%)')],loc='lower center',ncol=3,frameon=False,fontsize=8);save(fig,'literal01_filter_retention')
 fig,axes=plt.subplots(1,3,figsize=(11.8,3.8),sharey=True)
 measures=['all_event_change','positive_event_change','filtered_minus_all_change'];names=['All text','Qwen-positive','Filtered minus all']
 for ax,feature in zip(axes,LABELS):
  data=pair[pair.feature==feature].set_index('measure')
  for y,m in zip([2,1,0],measures):
   r=data.loc[m];v=100*r.estimate;lo=100*r.ci95_low;hi=100*r.ci95_high;ax.errorbar(v,y,xerr=[[v-lo],[hi-v]],fmt='o',capsize=3,color='#0072B2' if y else '#7655A2')
  low=float(data.ci95_low.min())*100;high=float(data.ci95_high.max())*100;span=high-low;ax.set_xlim(low-.12*span,high+.12*span);ax.axvline(0,color='.6',linewidth=.8);ax.set_ylim(-.5,2.5);ax.set_yticks([2,1,0],names);ax.xaxis.set_major_locator(MaxNLocator(4));ax.set_xlabel('Criterion contrast (percentage points)');ax.set_title(LABELS[feature],fontsize=10,fontweight='bold');ax.text(.5,.04,'Same 72 sources: 40 negative / 32 positive',transform=ax.transAxes,ha='center',fontsize=8)
 fig.tight_layout(w_pad=2);save(fig,'literal02_matched_filter_comparison')
 word=raw[(raw.text_view=='full')&(raw.stratum=='all')&(raw.criterion=='all')&~raw.feature.isin(LABELS)][['feature','n_texts_with_feature','n_feature_occurrences','n_papers_with_feature']]
 principal=[]
 for feat in LABELS:
  x=raw[(raw.text_view=='full')&(raw.stratum=='all')&(raw.criterion=='all')&(raw.feature==feat)].iloc[0];r=rr[rr.feature==feat].iloc[0];s=summ[(summ.scenario=='full_all')&(summ.feature==feat)&(summ.endpoint=='event_incidence')].iloc[0]
  principal.append({'Observable':LABELS[feat],'Hit texts':int(x.n_texts_with_feature),'Occurrences':int(x.n_feature_occurrences),'Papers with hit':int(x.n_papers_with_feature),'Positive / negative hit texts':f'{int(r.qwen_positive_hit_contexts)} / {int(r.qwen_negative_hit_contexts)}','Event difference (pp)':pp(s.estimate),'95% source CI (pp)':f'[{pp(s.ci95_low)}, {pp(s.ci95_high)}]'})
 shift=pair[(pair.feature=='replication_word_tokens')&(pair.measure=='filtered_minus_all_change')].iloc[0];sc=comp[comp.feature=='replication_word_tokens'].iloc[0]
 rows=[]
 for _,r in pair.iterrows():rows.append({'Observable':LABELS[r.feature],'Comparison':r.measure,'Negative / positive n':f'{int(r.n_negative)} / {int(r.n_positive)}','Difference (pp)':pp(r.estimate),'95% source CI (pp)':f'[{pp(r.ci95_low)}, {pp(r.ci95_high)}]'})
 text=f'''# Literal wording diagnostic: a supplementary selection check

## What was added and why

This diagnostic counts visible word forms in the frozen 105-source-paper corpus without any new model call or human labeling. Its purpose is to check how the certainty-analysis filter changes a clearly defined textual denominator. It is not a new certainty scale, hedging classifier, validation set, or measure of target-specific failure acknowledgment.

The original archive already contained a broader hedge/booster dictionary. Moreover, the certainty prompt explicitly lists some of these words as low-score cues and assigns special treatment to failed-replication discussion. Agreement between literal cues and that score is partly built into its instructions and cannot independently validate it.

## Fixed observables and units

Rules were written and hashed at 2026-10-05 19:26:08 UTC, before lexical counts or outcome comparisons. The earlier model-score results were already known, so this is a post hoc supplementary analysis, not preregistration. All predefined words and specifications are retained, including sparse or zero results.

- Primary adverb family: exact possibly, perhaps, probably
- Separate replication vocabulary: replicate, replicates, replicated, replicating, replication, replications
- Sensitivity only: originally lowercase may, might, could, with fixed numeric-adjacent may exclusion

Core and replication matching are case-insensitive whole-token rules. Replication possessives are accepted. Tokens are Unicode alphabetic sequences with at most one internal apostrophe; there is no stemming, synonym expansion, normalization, language classifier or semantic parsing. The modal sensitivity deliberately excludes capitalized forms and a fixed ASCII-number adjacency pattern; it still contains permission/ability and nominal uses. Synthetic tests corrected implementation boundary defects without changing the frozen word lists.

A primary observation is a retained exact text unit containing at least one match. Occurrence counts and alphabetic-token denominators are also supplied. A word hit does not determine its scope, polarity, target relevance or semantic function. Replication vocabulary is neither necessary nor sufficient for acknowledgment and provides no lower or upper bound on acknowledgment prevalence. English cue absence does not imply absence of qualification in other words or languages.

## Raw accounting and primary event comparisons

The corpus has 15,280 text units: 8,427 Qwen-positive and 6,853 Qwen-negative. No negative text is assigned certainty zero. The table reports all texts, including those excluded from certainty scoring. Family counts are unique per text, so individual-word text counts can sum to more than the family total.

{table(pd.DataFrame(principal),list(principal[0]))}

The three-adverb family occurs in only 87 texts (0.57%) from 52 sources. Within the 85 all-text event-eligible sources, only 72 text units contain a core adverb and 42 sources have no such hit. Within the 72 positive-text event sources, 52 text units contain a core adverb and 41 sources have no hit. These zeros are retained. Such narrow and sparse coverage cannot corroborate a broad conclusion of unchanged certainty. Replication-word forms occur in 304 texts; 171/304 (56.25%) fall outside the Qwen-positive subset. This is a property of the frozen conditional corpus, not an estimate of literature-wide prevalence and not proof that the filter made errors.

The main event estimates use 85 sources (44 criterion-negative, 41 criterion-positive) with at least ten retained texts before and at/after the project journal-publication year. Each source has equal weight. The word-count threshold is never used for eligibility; observed zeros stay in the analysis. Intervals resample sources within criterion groups 19,999 times and condition on fixed retrieval, source criteria, dates and lexical rules.

## Same-source filter comparison

To separate changes in support from changes in the text denominator, both all-text and Qwen-positive rates were recomputed on the identical 72 sources satisfying the positive-text ten-per-period rule.

{table(pd.DataFrame(rows),list(rows[0]))}

For replication-word incidence, restricting to Qwen-positive text changes the criterion-negative-minus-positive event contrast by {pp(shift.estimate)} percentage points, with a source-bootstrap interval [{pp(shift.ci95_low)}, {pp(shift.ci95_high)}]. A sensitivity resampling the 89 connected source groups linked by shared exact text gives [{pp(sc.ci95_low)}, {pp(sc.ci95_high)}] percentage points for this shift. These intervals do not model unobserved shared citing articles.

This difference shows that the chosen text-function subset can materially change a literal wording comparison. It does not identify a causal effect of filtering, prove that replication discussion was misclassified, or validate the original model score. The criteria group contrast is descriptive; successful/criterion-positive source papers are not an untreated control.

## Every predefined word

{table(word,list(word.columns))}

## Truncation, timing and other limits

The archive's Qwen call used at most 700 characters and the DeepSeek call at most 1,200. Of the 15,280 retained texts, 112 exceed 700 characters and 54 exceed 1,200. Prefix sensitivity counts only full-text tokens wholly visible within the limit, preventing a cut token from becoming a false cue.

The full-text adverb family appears in 87 contexts, compared with 82 in the first 700 characters and 84 in the first 1,200. Replication-family presence remains 304 under both limits, although token multiplicity changes. This does not establish that every classification-relevant part of those texts was visible to the models.

Recorded manuscript-upload timing, omission of the event year, a symmetric five-year window, latest archived candidate text year, token-density normalization and leave-one-project-out diagnostics are supplied without selecting favorable results. Main journal years are RPP 2015, EERP 2016, ML1 2014 and ML3 2016. Historical upload timestamps do not certify exact historical file content, first evidence or awareness.

The cache is a purposively retrieved set of text strings with uncertain citing-record provenance and date conflicts. The three source cases excluded under the conservative source-level inclusion convention remain outside this fixed 105-paper diagnostic. This is a scope/inclusion decision; it must not be read as a claim that every individual statistic in those cases is unknown. Any Staunton-selected RPP73 extension is reported separately. Local occurrence counts cannot establish scientific correction, author belief, or response to an exact replicated proposition. This addition is suitable as a transparent supplementary limitation/triangulation analysis, not a replacement headline finding or independent measurement validation.

## Published rule basis

- [Kilicoglu and Bergler (2008), Table 1](https://link.springer.com/article/10.1186/1471-2105-9-S11-S10) supplies the three adverb examples and explains modal/context ambiguity. We use literal forms, not its classifier or reported accuracy
- [Morante and Daelemans (2009)](https://aclanthology.org/W09-1304/) distinguishes cue detection from scope and evaluates a simple dictionary baseline
- [Farkas et al. (2010)](https://aclanthology.org/W10-3001/) treats cue recognition and scope as distinct tasks
- [Szarvas et al. (2012), §2.2 and Table 1](https://aclanthology.org/J12-2004.pdf) distinguishes epistemic and other semantic uses of uncertainty-related forms

The exact frozen rules, implementation clarification, aggregate inputs, source-level estimates, all wordwise results and reproducible scripts accompany this note. No raw citation text or individual human annotation is distributed in the cleaned checkpoint.
'''
 (ROOT/'LITERAL_DIAGNOSTIC.md').write_text(text)
 captions={'literal01_filter_retention':'Literal-feature text units partitioned by the existing Qwen filter. Numbers in segments are raw text counts. The dotted line is the overall 8427/15280 positive fraction. A replication-word hit is not necessarily target-specific evidence discussion or acknowledgment; exclusions do not establish classification error.','literal02_matched_filter_comparison':'All rows use the same 72 sources (40 criterion-negative, 32 criterion-positive). Points show negative-minus-positive differences in source-specific post-minus-pre literal-feature incidence; the third row is the difference between positive-only and all-text changes. Bars are conditional 95% source-bootstrap intervals. The modal family is a polysemy-sensitive surface-form check. Comparisons are post hoc descriptions, not causal effects or new certainty measurements.'}
 (F/'figure_captions.json').write_text(json.dumps(captions,indent=2)+'\n');print('Built recipient-facing literal diagnostic and2 figures')
if __name__=='__main__':main()
