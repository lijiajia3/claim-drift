import unittest
from literal_features import features
class LiteralRules(unittest.TestCase):
 def test_exact_adverbs(self):
  x=features('Possibly, perhaps and probably; possibility improbable probabilities.');self.assertEqual(x['token_epistemic_adverb_tokens'],3)
 def test_unicode_boundary(self):
  x=features('épossibly possibly2 _perhaps perhaps_ probably中文 probably');self.assertEqual(x['token_epistemic_adverb_tokens'],1)
 def test_unicode_not_normalized(self):
  self.assertEqual(features('ｐｒｏｂａｂｌｙ')['token_probably'],0)
 def test_no_stemming(self):
  self.assertEqual(features('replicability reproducibility replicas replicable replicator')['token_replication_word_tokens'],0)
 def test_replication_forms_and_possessive(self):
  self.assertEqual(features("Replicate replicates replicated replicating replication replications replication’s")['token_replication_word_tokens'],7)
 def test_polysemy_retained(self):
  self.assertEqual(features('DNA replication and military might could not work')['token_replication_word_tokens'],1)
  self.assertEqual(features('military might could not work')['token_lowercase_modal_tokens'],2)
 def test_case_exclusion(self):
  x=features('May MAY may Might MIGHT might Could COULD could');self.assertEqual(x['token_lowercase_modal_tokens'],3);self.assertEqual(x['excluded_modal_case'],6)
 def test_date_adjacency(self):
  x=features('may 2016; 12 may; may, 4; may influence; May et al.');self.assertEqual(x['token_may'],1);self.assertEqual(x['excluded_may_numeric'],3);self.assertEqual(x['excluded_case_may'],1)
 def test_complete_prefix(self):
  x=features('possibly',5);self.assertEqual(x['token_possibly'],0);self.assertEqual(x['n_tokens'],0)
  self.assertEqual(features('possibly',8)['token_possibly'],1)
 def test_hyphen(self):
  self.assertEqual(features('replication-based perhaps-related')['token_replication_word_tokens'],1)
 def test_negation_and_quotes_remain_literal(self):
  x=features('"probably" is not a claim; not replicated.');self.assertEqual(x['token_probably'],1);self.assertEqual(x['token_replicated'],1)
 def test_binary_versus_count(self):
  x=features('perhaps perhaps perhaps');self.assertEqual(x['context_epistemic_adverb_tokens'],1);self.assertEqual(x['token_epistemic_adverb_tokens'],3)
if __name__=='__main__':unittest.main(verbosity=2)
