#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export OPENBLAS_NUM_THREADS=1
export MPLCONFIGDIR="${TMPDIR:-/tmp}/scientometrics_matplotlib"
python src/run_analysis.py
python src/precision_simulation.py
python src/make_figures.py
python src/verify_checkpoint.py
python lexical/src/analyze_literal_counts.py
python lexical/src/staunton_selected_sensitivity.py
python lexical/src/make_literal_report.py
python -m unittest discover -s lexical/src -p 'test_literal*.py' -v
python lexical/src/verify_literal_checkpoint.py
