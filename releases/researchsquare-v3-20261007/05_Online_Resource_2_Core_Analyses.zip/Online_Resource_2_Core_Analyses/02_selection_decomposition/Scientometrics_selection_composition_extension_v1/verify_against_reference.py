#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent
checks=[]
for ref in sorted((R/'reference_outputs').glob('*.csv')):
 got=R/'selection_outputs'/ref.name
 a=pd.read_csv(ref);b=pd.read_csv(got)
 assert list(a.columns)==list(b.columns),ref.name
 assert a.shape==b.shape,ref.name
 for col in a:
  if pd.api.types.is_numeric_dtype(a[col]) and pd.api.types.is_numeric_dtype(b[col]):
   assert np.allclose(a[col],b[col],atol=1e-12,rtol=1e-12,equal_nan=True),(ref.name,col)
  else: assert a[col].fillna('<NA>').tolist()==b[col].fillna('<NA>').tolist(),(ref.name,col)
 checks.append({'file':ref.name,'rows':len(a),'verified':True})
a=json.loads((R/'reference_outputs/influence_summary.json').read_text());b=json.loads((R/'selection_outputs/influence_summary.json').read_text());assert a==b
out={'status':'verified','csv_files':len(checks),'csv_checks':checks,'influence_summary_exact':True,'tolerance':1e-12}
(R/'REPLAY_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
