#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m unittest test_selection_decomposition.py -v
python analyze_selection_decomposition.py
python make_selection_report.py
python verify_against_reference.py
python independent_review/verify_selection_decomposition.py --extension-root .
python independent_review/compare_production_outputs.py --extension-root .
