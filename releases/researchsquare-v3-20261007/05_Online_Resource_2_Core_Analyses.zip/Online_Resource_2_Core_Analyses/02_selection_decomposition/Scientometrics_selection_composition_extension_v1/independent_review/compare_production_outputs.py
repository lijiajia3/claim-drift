#!/usr/bin/env python3
"""Audit production CSVs against independently reconstructed values and bootstraps.
Does not execute or import production analysis code.
"""
from pathlib import Path
import pandas as pd, numpy as np, json, hashlib, argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--extension-root',type=Path,default=Path(__file__).resolve().parent.parent)
args=parser.parse_args()
ROOT=args.extension_root.resolve()
H=ROOT/'independent_review';O=ROOT/'selection_outputs'
I=ROOT/'inputs' if (ROOT/'inputs').is_dir() else ROOT.parent/'scientometrics_analysis'/'lexical'/'inputs'
B=19999;SEED=20261006
checks=[]
def ck(name,v,detail=None):
 checks.append({'check':name,'pass':bool(v),'detail':detail})
 if not v: raise AssertionError((name,detail))
def close(name,a,b):
 a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float)
 ck(name,np.allclose(a,b,atol=2e-14,rtol=0,equal_nan=True),float(np.nanmax(np.abs(a-b))) if a.size else 0)
def frame(name,ours,theirs,keys,cols):
 ck(name+' rows',len(ours)==len(theirs),(len(ours),len(theirs)))
 a=ours.set_index(keys).sort_index();b=theirs.set_index(keys).sort_index();ck(name+' keys',a.index.equals(b.index))
 for x,y in cols.items():
  if a[x].dtype.kind in 'biufc':close(name+' '+x,a[x],b[y])
  else:ck(name+' '+x,(a[x].fillna('')==b[y].fillna('')).all())
d=pd.read_csv(H/'independent_source_estimates.csv');main=d[d.scenario=='primary']
metrics={'total':'filter_shift','retention':'retention_component','stratum_distribution':'stratum_distribution_component','account_retained':'account_retained_weight','account_excluded':'account_excluded_incidence'}
mapcols={**metrics,'source_id':'source_id','project':'project','criterion':'criterion','decomposition_supported':'decomposition_eligible','excluded_ten_supported':'negative10_eligible','all_event_change':'all_event_change','positive_event_change':'positive_event_change'}
for t in ['pre','post']:
 mapcols.update({'n_positive_'+t:t+'_n_positive','n_excluded_'+t:t+'_n_negative','hit_positive_'+t:t+'_hit_positive','hit_excluded_'+t:t+'_hit_negative','p_positive_'+t:t+'_positive_incidence','p_excluded_'+t:t+'_negative_incidence','p_all_'+t:t+'_all_incidence','q_'+t:t+'_excluded_share','gap_'+t:t+'_filter_gap'})
prod=pd.read_csv(O/'source_period_decomposition.csv').rename(columns={'feature':'family'})
frame('primary source values',main,prod,['analysis_claim_id','family'],mapcols)
prodall=pd.read_csv(O/'all_timing_source_estimates.csv').rename(columns={'feature':'family','timing':'scenario'});prodall.scenario=prodall.scenario.replace('journal','primary')
frame('all timing source values',d,prodall,['scenario','analysis_claim_id','family'],mapcols)
# Base point estimates are compared independently of any RNG stream.
submap={'full72':'full72','nonempty_excluded_both':'nonempty_negative_each_period','ten_excluded_both':'negative10_each_period'}
ours=pd.read_csv(H/'independent_component_summaries.csv');ours=ours[ours.bootstrap=='source'].copy();ours['cohort']=ours.subset.map(submap);ours['metric']=ours.measure.map(metrics)
prod=pd.read_csv(O/'source_bootstrap_components.csv').rename(columns={'feature':'family'})
frame('source point summaries',ours,prod,['cohort','family','metric'],{'estimate':'estimate','n_negative':'n_negative','n_positive':'n_positive'})
# Replay production random-stream ordering with our independently built source table.
def replay_source(z,mm):
 arrs=[z[z.criterion==g].sort_values('analysis_claim_id')[mm].to_numpy() for g in ['failed','successful']]
 rng=np.random.default_rng(SEED);ncols=len(mm);draws=np.empty((B,ncols))
 # Independent weighted-frequency implementation: same categorical draws,
 # means computed through multinomial source weights rather than indexed array means.
 for start in range(0,B,1000):
  n=min(1000,B-start);draws[start:start+n]=0
  for sign,a in zip([1,-1],arrs):
   ix=rng.integers(0,len(a),size=(n,len(a)))
   freq=np.zeros((n,len(a)),dtype=int)
   np.add.at(freq,(np.arange(n)[:,None],ix),1)
   draws[start:start+n]+=sign*(freq@a)/len(a)
 return np.quantile(draws,[.025,.975],axis=0)
for family in main.family.unique():
 z=main[main.family==family]
 for subset,zz in [('full72',z),('nonempty_negative_each_period',z[z.decomposition_supported]),('negative10_each_period',z[z.excluded_ten_supported])]:
  mm=['total','account_retained','account_excluded'] if subset=='full72' else list(metrics)
  q=replay_source(zz,mm);tab=prod[(prod.family==family)&(prod.cohort==subset)].set_index('metric')
  for j,m in enumerate(mm):close('source bootstrap exact endpoints '+family+' '+subset+' '+m,q[:,j],tab.loc[metrics[m],['ci95_low','ci95_high']])
# Fixed entire 89-component graph, preserving all cross-group memberships.
member=pd.read_csv(I/'shared_text_component_membership.csv');allcomp=sorted(member.component_id.unique());ck('89 frozen components',len(allcomp)==89)
ct={v:i for i,v in enumerate(allcomp)}
component_prod=pd.read_csv(O/'shared_component_bootstrap.csv')
for family in main.family.unique():
 z=main[main.family==family]
 for subset,zz in [('full72',z),('nonempty_negative_each_period',z[z.decomposition_supported]),('negative10_each_period',z[z.excluded_ten_supported])]:
  mm=['total','account_retained','account_excluded'] if subset=='full72' else list(metrics)
  ids=zz.sort_values('analysis_claim_id');n=len(ids)
  component_source=np.zeros((89,n))
  for j,c in enumerate(ids.component_id):component_source[ct[c],j]=1
  a=ids[mm].to_numpy();g=(ids.criterion=='failed').to_numpy();rng=np.random.default_rng(SEED);draw=[];dropped=0
  for start in range(0,B,500):
   nn=min(500,B-start);index=rng.integers(0,89,size=(nn,89));freq=np.zeros((nn,89),dtype=int)
   np.add.at(freq,(np.arange(nn)[:,None],index),1)
   sw=freq@component_source;gn=sw[:,g].sum(1);gp=sw[:,~g].sum(1);ok=(gn>0)&(gp>0);dropped+=int((~ok).sum())
   v=(sw[ok][:,g]@a[g])/gn[ok,None]-(sw[ok][:,~g]@a[~g])/gp[ok,None];draw.append(v)
  q=np.quantile(np.vstack(draw),[.025,.975],axis=0);tab=component_prod[(component_prod.feature==family)&(component_prod.cohort==subset)].set_index('metric')
  for j,m in enumerate(mm):close('89-component bootstrap endpoints '+family+' '+subset+' '+m,q[:,j],tab.loc[metrics[m],['ci95_low','ci95_high']])
  ck('component dropped draws '+family+' '+subset,(tab.dropped_draws==dropped).all())
  ck('component matched support '+family+' '+subset,(tab.n_components_with_eligible_source==ids.component_id.nunique()).all())
  ck('component frozen frame '+family+' '+subset,(tab.n_components_in_fixed_graph==89).all())
# Influence, support, standardization, timing.
a=pd.read_csv(H/'independent_leave_source_out.csv');b=pd.read_csv(O/'leave_source_out.csv').rename(columns={'feature':'family'})
frame('all source deletion results',a,b,['family','analysis_claim_id'],{'source_shift':'source_filter_shift','estimate_without_source':'estimate_omitting_source','change_from_full':'change_from_full_estimate'})
a=pd.read_csv(H/'independent_signed_source_contributions.csv')
frame('all signed source contributions',a,b,['family','analysis_claim_id'],{'signed_contribution':'signed_contribution_to_full_contrast'})
for af,bf,key,col in [('independent_leave_project_out.csv','leave_project_out.csv','left_out_project','omitted_project'),('independent_within_project.csv','within_project.csv','project','project')]:
 a=pd.read_csv(H/af);b=pd.read_csv(O/bf).rename(columns={'feature':'family',col:key})
 frame(af,a,b,['family',key],{'estimate':'estimate','n_negative':'n_negative','n_positive':'n_positive'})
 if 'within' in af:ck('ML1 direct within-project intervals omitted',b.loc[b[key]=='ML1',['ci95_low','ci95_high']].isna().all().all())
 for _,row in b.iterrows():
  z=main[(main.family==row.family)&((main.project==row[key]) if 'within' in af else (main.project!=row[key]))]
  if min(z.criterion.value_counts())<2:continue
  close(af+' endpoints '+row.family+' '+row[key],replay_source(z,['total'])[:,0],row[['ci95_low','ci95_high']])
a=pd.read_csv(H/'independent_timing_summary.csv');b=pd.read_csv(O/'timing_filter_shift.csv').rename(columns={'feature':'family','cohort':'scenario'});b.scenario=b.scenario.replace('journal','primary')
frame('timing summary',a,b,['family','scenario'],{'estimate':'estimate','n_negative':'n_negative','n_positive':'n_positive','n_overlap_primary':'n_sources_also_in_primary72','n_added_to_primary':'n_sources_not_in_primary72'})
for _,r in b.iterrows():close('timing exact endpoints '+r.family+' '+r.scenario,replay_source(d[(d.family==r.family)&(d.scenario==r.scenario)],['total'])[:,0],r[['ci95_low','ci95_high']])
a=pd.read_csv(H/'independent_project_standardized.csv');a.weighting=a.weighting.replace('pooled_matched_source','pooled_source_project_weights');b=pd.read_csv(O/'project_standardized.csv').rename(columns={'feature':'family','weight_mode':'weighting'})
frame('standardized point estimates',a,b,['family','weighting'],{'estimate':'estimate'})
for _,r in b.iterrows():
 weights=json.loads(r.weights_json);z=main[main.family==r.family];rng=np.random.default_rng(SEED);draw=np.zeros(B)
 for p,w in weights.items():close('project weight '+r.family+' '+r.weighting+' '+p,[w],[.25 if r.weighting=='equal_project' else (z.project==p).mean()])
 for start in range(0,B,1000):
  nn=min(1000,B-start)
  for p,w in sorted(weights.items()):
   for g,sign in [('failed',1),('successful',-1)]:
    a=z[(z.project==p)&(z.criterion==g)].sort_values('analysis_claim_id').total.to_numpy();ii=rng.integers(len(a),size=(nn,len(a)));freq=np.zeros((nn,len(a)),int);np.add.at(freq,(np.arange(nn)[:,None],ii),1)
    draw[start:start+nn]+=sign*w*(freq@a)/len(a)
 q=np.quantile(draw,[.025,.975]);ck('standardized singleton cell present '+r.family+' '+r.weighting,json.loads(r.cell_counts_json)['ML1']['failed']==1)
 # New production versions may suppress publication-facing interval columns.
 if pd.notna(r.ci95_low):close('standardized exact conditional endpoints '+r.family+' '+r.weighting,q,r[['ci95_low','ci95_high']])
 elif 'audit_conditional_ci95_low' in r.index:close('standardized exact conditional endpoints '+r.family+' '+r.weighting,q,r[['audit_conditional_ci95_low','audit_conditional_ci95_high']])
 else:ck('standardized conservative interval omission '+r.family+' '+r.weighting,pd.isna(r.ci95_high))
# Header-only nondecomposable output is correct, rather than fabricated zeros.
ck('empty-stratum output contains no sources',len(pd.read_csv(O/'nondecomposable_sources.csv'))==0)
script=(H.parent/'analyze_selection_decomposition.py').read_text()
ck('production excludes empty negative strata from symmetric decomposition','pn=hn/nn if nn else np.nan' in script and "r['retention_component']=np.nan;r['stratum_distribution_component']=np.nan" in script)
# Zero-stratum identity edge cases use exact rationals; product decomposition remains undefined.
from fractions import Fraction as F
for npos,hpos,nneg,hneg in [(10,0,0,0),(10,4,0,0),(10,10,0,0),(10,4,1,0),(10,4,1,1)]:
 pp=F(hpos,npos);q=F(nneg,npos+nneg);pa=F(hpos+hneg,npos+nneg)
 ck('synthetic full-support edge '+str((npos,hpos,nneg,hneg)),pp-pa==q*pp-F(hneg,npos+nneg))
 if nneg==0:ck('synthetic absent excluded denominator '+str(hpos),q==0 and pp-pa==0)
# Top five and ranges must reflect complete file, not a selected subset.
b=pd.read_csv(O/'leave_source_out.csv');influence=json.loads((O/'influence_summary.json').read_text())
for row in influence:
 z=b[b.feature==row['feature']]
 close('influence extrema '+row['feature'],[z.estimate_omitting_source.min(),z.estimate_omitting_source.max(),z.change_from_full_estimate.abs().max()],[row['minimum_source_deletion_estimate'],row['maximum_source_deletion_estimate'],row['maximum_absolute_source_deletion_change']])
 actual=z.assign(ab=z.signed_contribution_to_full_contrast.abs()).sort_values('ab',ascending=False).head(5).analysis_claim_id.tolist()
 ck('top-five identities '+row['feature'],actual==[r['analysis_claim_id'] for r in row['top_five_absolute_signed_contributions']])
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()};hashes['analyze_selection_decomposition.py']=hashlib.sha256((H.parent/'analyze_selection_decomposition.py').read_bytes()).hexdigest()
(H/'production_comparison_checks.json').write_text(json.dumps({'all_passed':all(c['pass'] for c in checks),'n_checks':len(checks),'checks':checks,'production_hashes':hashes},indent=2)+'\n')
print('PASS',len(checks),'production cross-comparison checks')
