#!/usr/bin/env python3
"""Independent reconstruction from aggregate counts; does not import production code.
Frozen dictionary and cohort only. No raw text, inference calls, or external I/O.
"""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict, Counter
import csv, hashlib, json, argparse
import numpy as np
import pandas as pd

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--extension-root',type=Path,default=Path(__file__).resolve().parent.parent)
args=parser.parse_args()
ROOT=args.extension_root.resolve()
HERE=ROOT/'independent_review'
HERE.mkdir(parents=True,exist_ok=True)
BASE=ROOT.parent/'scientometrics_analysis'/'lexical'
INPUT=ROOT/'inputs' if (ROOT/'inputs').is_dir() else BASE/'inputs'
OLD=ROOT/'previous' if (ROOT/'previous').is_dir() else BASE/'outputs'
PROTOCOL=ROOT/'SELECTION_DECOMPOSITION_PROTOCOL.md'
EXPECTED_PROTOCOL='167f2ce696b06d0f0608b94040a85a22ecb0d2113bd99294db7956e60b42863e'
FAMILIES=['epistemic_adverb_tokens','replication_word_tokens','lowercase_modal_tokens']
SEED=20261006
B=19999
SCENARIOS={
 'primary':('event_year_journal',False,0,False,'full'),
 'recorded_manuscript_upload_years':('event_year_first_located_manuscript',False,0,False,'recorded_manuscript_upload_years'),
 'omit_event_year':('event_year_journal',True,0,False,'omit_event_year'),
 'symmetric5_years_omit_event_year':('event_year_journal',True,5,False,'symmetric5_years_omit_event_year'),
 'latest_archived_year':('event_year_journal',False,0,True,'latest_archived_year'),
}
CHECKS=[]
def check(name,condition,detail=None):
 CHECKS.append({'check':name,'pass':bool(condition),'detail':detail})
 if not condition: raise AssertionError(f'{name}: {detail}')
def read(path):
 with open(path,newline='') as f: return list(csv.DictReader(f))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(frame,name): frame.to_csv(HERE/name,index=False,float_format='%.17g')

check('frozen protocol hash',sha(PROTOCOL)==EXPECTED_PROTOCOL)
cohort=read(INPUT/'source_cohort.csv'); membership=read(INPUT/'shared_text_component_membership.csv')
meta={r['analysis_claim_id']:r for r in cohort}
components={r['analysis_claim_id']:int(r['component_id']) for r in membership}
check('105 unique included sources',len(meta)==len(cohort)==105 and all(r['include_primary']=='True' for r in cohort))
check('complete source component membership',set(meta)==set(components))
component_sizes=Counter(components.values())
check('component sizes',all(component_sizes[int(r['component_id'])]==int(r['component_size']) for r in membership))
raw=read(INPUT/'literal_counts_by_source_year.csv')
full=[r for r in raw if r['text_view']=='full']
keycols=['analysis_claim_id','year','latest_year','assertion','text_view']
check('unique aggregate row keys',len({tuple(r[k] for k in keycols) for r in raw})==len(raw))
check('all counts nonnegative integers',all(int(v)>=0 and str(int(v))==v for r in raw for k,v in r.items() if k not in keycols+['source_id']))
for f in FAMILIES:
 check(f+' context hits bounded by text count',all(0<=int(r['context_'+f])<=int(r['n_texts']) for r in raw))
 check(f+' token occurrences cover context hits',all(int(r['token_'+f])>=int(r['context_'+f]) for r in raw))
words={'epistemic_adverb_tokens':['possibly','perhaps','probably'],'replication_word_tokens':['replicate','replicates','replicated','replicating','replication','replications'],'lowercase_modal_tokens':['may','might','could']}
for f,ww in words.items():
 check(f+' token sum conservation',all(sum(int(r['token_'+w]) for w in ww)==int(r['token_'+f]) for r in raw))
 check(f+' context union bounds',all(max(int(r['context_'+w]) for w in ww)<=int(r['context_'+f])<=sum(int(r['context_'+w]) for w in ww) for r in raw))
for sid,m in meta.items():
 rows=[r for r in full if r['analysis_claim_id']==sid]
 check('cohort count conservation '+sid,sum(int(r['n_texts']) for r in rows)==int(m['count_contexts']) and sum(int(r['n_texts']) for r in rows if r['assertion']=='1')==int(m['count_filter_positive']))
check('full corpus totals',sum(int(r['n_texts']) for r in full)==15280 and sum(int(r['n_texts']) for r in full if r['assertion']=='1')==8427)
# Exact-rational formulas make identity verification independent of floating rounding.
records=[]; counts=[]
for scenario,(event_col,omit,window,latest,old_name) in SCENARIOS.items():
 agg=defaultdict(lambda:[0,0,0,0]) # text count then three context-family hits
 for row in full:
  sid=row['analysis_claim_id']; year=int(row['latest_year' if latest else 'year']); event=int(meta[sid][event_col])
  if omit and year==event: continue
  if window and not event-window<=year<=event+window: continue
  period='pre' if year<event else 'post'
  cell=agg[(sid,period,int(row['assertion']))]
  vals=[int(row['n_texts'])]+[int(row['context_'+f]) for f in FAMILIES]
  for k,v in enumerate(vals): cell[k]+=v
 for sid in sorted(meta):
  m=meta[sid]; cells={(t,a):agg[(sid,t,a)] for t in ['pre','post'] for a in [0,1]}
  eligible=all(cells[(t,1)][0]>=10 for t in ['pre','post'])
  cr={'scenario':scenario,'analysis_claim_id':sid,'source_id':m['source_id'],'project':m['project'],'criterion':m['revised_outcome'],'eligible':eligible}
  for (t,a),v in cells.items(): cr[f'n_{"positive" if a else "excluded"}_{t}']=v[0]
  counts.append(cr)
  if not eligible: continue
  supported=all(cells[(t,0)][0]>0 for t in ['pre','post'])
  ten=all(cells[(t,0)][0]>=10 for t in ['pre','post'])
  for fidx,f in enumerate(FAMILIES,1):
   rr={**cr,'family':f,'component_id':components[sid],'decomposition_supported':supported,'excluded_ten_supported':ten}
   vals={}
   for t in ['pre','post']:
    pos=cells[t,1];neg=cells[t,0]; nall=pos[0]+neg[0]
    pp=Fraction(pos[fidx],pos[0]);pa=Fraction(pos[fidx]+neg[fidx],nall);q=Fraction(neg[0],nall)
    g=pp-pa; aa=q*pp;bb=-Fraction(neg[fidx],nall)
    check(f'exact full-support identity {scenario} {sid} {f} {t}',g==aa+bb)
    pm=Fraction(neg[fidx],neg[0]) if neg[0] else None
    if pm is not None: check(f'exact gap product {scenario} {sid} {f} {t}',g==q*(pp-pm))
    vals[t]={'p_positive':pp,'p_all':pa,'q':q,'gap':g,'account_retained':aa,'account_excluded':bb,'p_excluded':pm}
    for k,v in vals[t].items(): rr[k+'_'+t]=float(v) if v is not None else np.nan
    rr['hit_positive_'+t]=pos[fidx];rr['hit_excluded_'+t]=neg[fidx]
   for out,key in [('total','gap'),('account_retained','account_retained'),('account_excluded','account_excluded'),('positive_event_change','p_positive'),('all_event_change','p_all')]:
    rr[out]=float(vals['post'][key]-vals['pre'][key])
   if supported:
    d0=vals['pre']['p_positive']-vals['pre']['p_excluded'];d1=vals['post']['p_positive']-vals['post']['p_excluded']
    q0=vals['pre']['q'];q1=vals['post']['q']
    rc=(q1-q0)*(d1+d0)/2;sc=(d1-d0)*(q1+q0)/2
    check(f'exact symmetric identity {scenario} {sid} {f}',rc+sc==vals['post']['gap']-vals['pre']['gap'])
    rr.update(retention=float(rc),stratum_distribution=float(sc))
   else: rr.update(retention=np.nan,stratum_distribution=np.nan)
   records.append(rr)
df=pd.DataFrame(records); counts=pd.DataFrame(counts)
main=df[df.scenario=='primary'].copy()
check('primary matched 72 sources',main.analysis_claim_id.nunique()==72)
check('primary criterion sizes',main.drop_duplicates('analysis_claim_id').criterion.value_counts().to_dict()=={'failed':40,'successful':32})
check('fixed identical source support across families',all(set(main[main.family==f].analysis_claim_id)==set(main.analysis_claim_id) for f in FAMILIES))
old=pd.read_csv(OLD/'matched_source_filter_estimates.csv')
merged=main.merge(old,left_on=['analysis_claim_id','family'],right_on=['analysis_claim_id','feature'],validate='one_to_one',suffixes=('','_old'))
check('archived source-family identity',len(merged)==len(main)==len(old))
for new,prev in [('total','filtered_minus_all_change'),('all_event_change','all_event_change_old'),('positive_event_change','positive_event_change_old')]:
 check('archived numeric equality '+new,np.allclose(merged[new],merged[prev],rtol=0,atol=2e-15),float((merged[new]-merged[prev]).abs().max()))
# Independently compare every timing count, hit, and positive eligibility against frozen source table.
old_est=pd.read_csv(OLD/'source_estimates_all_predefined_features.csv')
for scenario,(_,_,_,_,old_name) in SCENARIOS.items():
 for stratum in ['positive','all']:
  ref=old_est[(old_est.scenario==old_name+'_'+stratum)&old_est.feature.isin(FAMILIES)]
  new=df[df.scenario==scenario].merge(ref,left_on=['analysis_claim_id','family'],right_on=['analysis_claim_id','feature'],suffixes=('','_old'),validate='one_to_one')
  check(f'archived timing source membership {scenario} {stratum}',len(new)==len(df[df.scenario==scenario]))
  if stratum=='positive':
   old_eligible=set(ref.loc[(ref.n_pre>=10)&(ref.n_post>=10),'analysis_claim_id'])
   check('archived positive eligibility '+scenario,old_eligible==set(new.analysis_claim_id))
  for t in ['pre','post']:
   n=new['n_positive_'+t]+(new['n_excluded_'+t] if stratum=='all' else 0)
   h=new['hit_positive_'+t]+(new['hit_excluded_'+t] if stratum=='all' else 0)
   check(f'archived timing denominators {scenario} {stratum} {t}',(n==new['n_'+t]).all())
   check(f'archived timing numerators {scenario} {stratum} {t}',(h==new['hit_'+t]).all())

def matrix(z,measures):
 # One matrix includes all families and components so resamples are shared jointly.
 ids=sorted(z.analysis_claim_id.unique()); wide=z.set_index(['analysis_claim_id','family'])
 cols=[(f,m) for f in FAMILIES for m in measures]
 arr=np.array([[wide.loc[(sid,f),m] for f,m in cols] for sid in ids],dtype=float)
 mm=meta
 grp=np.array([mm[sid]['revised_outcome']=='failed' for sid in ids]); proj=np.array([mm[sid]['project'] for sid in ids]); comp=np.array([components[sid] for sid in ids])
 return ids,cols,arr,grp,proj,comp

def boot(z,measures,kind='source',project_weights=None):
 ids,cols,arr,grp,proj,comp=matrix(z,measures)
 rng=np.random.default_rng(SEED)
 if kind=='source':
  a=arr[grp];b=arr[~grp]
  ii=rng.integers(0,len(a),size=(B,len(a))); jj=rng.integers(0,len(b),size=(B,len(b)))
  draws=a[ii].mean(axis=1)-b[jj].mean(axis=1)
  point=a.mean(axis=0)-b.mean(axis=0)
 elif kind=='component':
  # All 89 frozen connected components are jointly selected across both criterion groups.
  # Components without eligible sources remain in the fixed sampling frame.
  uniq=np.array(sorted(set(components.values()))); ww=rng.multinomial(len(uniq),np.full(len(uniq),1/len(uniq)),size=B)
  ns=np.array([sum((comp==c)&grp) for c in uniq]);ps=np.array([sum((comp==c)&~grp) for c in uniq])
  sn=np.array([arr[(comp==c)&grp].sum(axis=0) for c in uniq]);sp=np.array([arr[(comp==c)&~grp].sum(axis=0) for c in uniq])
  dn=ww@ns;dp=ww@ps;valid=(dn>0)&(dp>0)
  draws=(ww[valid]@sn)/dn[valid,None]-(ww[valid]@sp)/dp[valid,None]
  point=arr[grp].mean(axis=0)-arr[~grp].mean(axis=0)
 elif kind=='project':
  draws=np.zeros((B,len(cols)));point=np.zeros(len(cols))
  for p,w in sorted(project_weights.items()):
   a=arr[(proj==p)&grp];b=arr[(proj==p)&~grp]
   check('supported project bootstrap '+p,len(a)>0 and len(b)>0)
   ii=rng.integers(0,len(a),size=(B,len(a)));jj=rng.integers(0,len(b),size=(B,len(b)))
   draws+=w*(a[ii].mean(axis=1)-b[jj].mean(axis=1));point+=w*(a.mean(axis=0)-b.mean(axis=0))
 else: raise ValueError(kind)
 if 'retention' in measures:
  for f in FAMILIES:
   kk=[cols.index((f,m)) for m in ['total','retention','stratum_distribution']]
   check('joint bootstrap symmetric conservation '+kind+' '+f,np.allclose(draws[:,kk[0]],draws[:,kk[1]]+draws[:,kk[2]],atol=1e-14,rtol=0))
 if 'account_retained' in measures:
  for f in FAMILIES:
   kk=[cols.index((f,m)) for m in ['total','account_retained','account_excluded']]
   check('joint bootstrap accounting conservation '+kind+' '+f,np.allclose(draws[:,kk[0]],draws[:,kk[1]]+draws[:,kk[2]],atol=1e-14,rtol=0))
 quant=np.quantile(draws,[.025,.975],axis=0)
 return pd.DataFrame([{'family':f,'measure':m,'estimate':point[j],'ci_low':quant[0,j],'ci_high':quant[1,j],'bootstrap':kind,'n_negative':int(grp.sum()),'n_positive':int((~grp).sum()),'replicates_valid':len(draws)} for j,(f,m) in enumerate(cols)])

summaries=[]
for subset,zz,measures in [
 ('full72',main,['total','account_retained','account_excluded']),
 ('nonempty_excluded_both',main[main.decomposition_supported],['total','retention','stratum_distribution','account_retained','account_excluded']),
 ('ten_excluded_both',main[main.excluded_ten_supported],['total','retention','stratum_distribution','account_retained','account_excluded'])]:
 for kind in ['source','component']:
  out=boot(zz,measures,kind);out['subset']=subset;summaries.append(out)
summary=pd.concat(summaries,ignore_index=True)
known=float(summary.query("family=='replication_word_tokens' and subset=='full72' and bootstrap=='source' and measure=='total'").estimate.iloc[0])
check('known full replication gap',abs(known-(-.015529040486321564))<2e-15,known)
# Group-level identities are checked independently of exact-rational row checks.
for subset,zz in [('full72',main),('nonempty_excluded_both',main[main.decomposition_supported]),('ten_excluded_both',main[main.excluded_ten_supported])]:
 for f in FAMILIES:
  z=zz[zz.family==f]
  contrast=lambda col:z[z.criterion=='failed'][col].mean()-z[z.criterion=='successful'][col].mean()
  check('group full-support conservation '+subset+' '+f,abs(contrast('total')-contrast('account_retained')-contrast('account_excluded'))<1e-14)
  if subset!='full72':check('group symmetric conservation '+subset+' '+f,abs(contrast('total')-contrast('retention')-contrast('stratum_distribution'))<1e-14)
# Within-project and leave-project-out: full matched-source sample only.
project_summaries=[];project_counts=[];lop=[];loo=[];contributions=[];weights=[];std=[]
projects=sorted(main.project.unique())
for p in projects:
 zz=main[main.project==p]; sizes=zz.drop_duplicates('analysis_claim_id').criterion.value_counts().to_dict()
 project_counts.append({'project':p,'n_negative':sizes.get('failed',0),'n_positive':sizes.get('successful',0)})
 if sizes.get('failed',0) and sizes.get('successful',0):
  out=boot(zz,['total']);out['project']=p
  if min(sizes.values())<2:out[['ci_low','ci_high']]=np.nan
  project_summaries.append(out)
 out=boot(main[main.project!=p],['total']);out['left_out_project']=p;lop.append(out)
for f in FAMILIES:
 zz=main[main.family==f];n=zz[zz.criterion=='failed'].total.to_numpy();p=zz[zz.criterion=='successful'].total.to_numpy();est=n.mean()-p.mean()
 for _,r in zz.iterrows():
  neg=r.criterion=='failed';v=float(r.total);coef=1/len(n) if neg else -1/len(p)
  analytic=(n.sum()-v)/(len(n)-1)-p.mean() if neg else n.mean()-(p.sum()-v)/(len(p)-1)
  rm=zz[zz.analysis_claim_id!=r.analysis_claim_id];direct=rm[rm.criterion=='failed'].total.mean()-rm[rm.criterion=='successful'].total.mean()
  check('source deletion formula '+f+' '+r.analysis_claim_id,abs(analytic-direct)<2e-15)
  loo.append({'family':f,'analysis_claim_id':r.analysis_claim_id,'source_id':r.source_id,'criterion':r.criterion,'project':r.project,'source_shift':v,'full_estimate':est,'estimate_without_source':direct,'change_from_full':direct-est})
  contributions.append({'family':f,'analysis_claim_id':r.analysis_claim_id,'source_id':r.source_id,'criterion':r.criterion,'project':r.project,'source_shift':v,'group_weight':coef,'signed_contribution':v*coef})
 check('source signed contribution sum '+f,abs(sum(x['signed_contribution'] for x in contributions if x['family']==f)-est)<2e-15)
check('four projects supported',len(project_counts)==4 and all(r['n_negative']>0 and r['n_positive']>0 for r in project_counts))
for weighting,w in [('equal_project',{p:1/len(projects) for p in projects}),('pooled_matched_source',{p:main[main.project==p].analysis_claim_id.nunique()/72 for p in projects})]:
 check('project weights sum '+weighting,abs(sum(w.values())-1)<1e-15)
 for p,weight in w.items():weights.append({'weighting':weighting,'project':p,'weight':weight})
 out=boot(main,['total'],'project',w);out['weighting']=weighting
 # Retain computational quantiles solely as conditional audit fields.
 out=out.rename(columns={'ci_low':'audit_conditional_ci_low','ci_high':'audit_conditional_ci_high'})
 out['ci_low']=np.nan;out['ci_high']=np.nan
 out['interval_warning']='Singleton ML1 criterion-negative cell has unestimated within-cell variation'
 std.append(out)
# Own eligibility for timing, not intersection restriction; exact intersections explicitly enumerated.
timing=[]; timing_ids=[]
primary=set(main.analysis_claim_id)
for sc in SCENARIOS:
 z=df[df.scenario==sc]; ss=set(z.analysis_claim_id);out=boot(z,['total']);out['scenario']=sc
 for key,value in [('n_overlap_primary',len(ss&primary)),('n_lost_from_primary',len(primary-ss)),('n_added_to_primary',len(ss-primary))]:out[key]=value
 timing.append(out)
 for sid in sorted(ss|primary):
  timing_ids.append({'scenario':sc,'analysis_claim_id':sid,'eligible_primary':sid in primary,'eligible_configuration':sid in ss})

# Output artifacts contain only permitted aggregate or source-summary data.
dump(df,'independent_source_estimates.csv');dump(counts,'independent_eligibility_counts.csv');dump(summary,'independent_component_summaries.csv')
dump(pd.concat(project_summaries,ignore_index=True),'independent_within_project.csv');dump(pd.DataFrame(project_counts),'independent_project_counts.csv')
dump(pd.concat(lop,ignore_index=True),'independent_leave_project_out.csv');dump(pd.DataFrame(loo),'independent_leave_source_out.csv')
con=pd.DataFrame(contributions);dump(con,'independent_signed_source_contributions.csv');dump(con.assign(abs_contribution=con.signed_contribution.abs()).sort_values(['family','abs_contribution'],ascending=[True,False]).groupby('family',sort=False).head(5),'independent_top_five_contributions.csv')
dump(pd.DataFrame(weights),'independent_project_weights.csv');dump(pd.concat(std,ignore_index=True),'independent_project_standardized.csv')
dump(pd.concat(timing,ignore_index=True),'independent_timing_summary.csv');dump(pd.DataFrame(timing_ids),'independent_timing_membership.csv')
dump(main[~main.decomposition_supported].drop_duplicates('analysis_claim_id')[['analysis_claim_id','source_id','project','criterion','n_positive_pre','n_positive_post','n_excluded_pre','n_excluded_post']],'independent_empty_strata.csv')
files=[PROTOCOL,INPUT/'literal_counts_by_source_year.csv',INPUT/'source_cohort.csv',INPUT/'shared_text_component_membership.csv',OLD/'matched_source_filter_estimates.csv',OLD/'matched_source_filter_comparison.csv',OLD/'source_estimates_all_predefined_features.csv',OLD/'analysis_configurations.json',Path(__file__)]
(HERE/'independent_hashes.json').write_text(json.dumps({str(p):sha(p) for p in files},indent=2)+'\n')
(HERE/'independent_checks.json').write_text(json.dumps({'seed':SEED,'bootstrap_replicates':B,'n_checks':len(CHECKS),'all_passed':all(c['pass'] for c in CHECKS),'checks':CHECKS},indent=2)+'\n')
print('PASS',len(CHECKS),'checks')
print(summary[(summary.bootstrap=='source')&(summary.measure.isin(['total','retention','stratum_distribution']))].to_string(index=False))
print('PROJECT COUNTS',project_counts)
print('EMPTY STRATA',main[~main.decomposition_supported][['source_id','criterion','n_excluded_pre','n_excluded_post']].drop_duplicates().to_string(index=False))
print('TIMING',pd.concat(timing).to_string(index=False))
