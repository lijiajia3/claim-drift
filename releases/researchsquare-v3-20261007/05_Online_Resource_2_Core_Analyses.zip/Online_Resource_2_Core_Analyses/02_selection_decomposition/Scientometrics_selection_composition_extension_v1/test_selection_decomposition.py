import unittest
import numpy as np
import pandas as pd
from analyze_selection_decomposition import fit_source, FEATURES, CONFIGS

class TestSelectionIdentities(unittest.TestCase):
    def test_random_arithmetic(self):
        rng=np.random.default_rng(20261006)
        for _ in range(1000):
            q0,q1,p0,p1,n0,n1=rng.random(6)
            d0=p0-n0;d1=p1-n1
            r=(q1-q0)*(d1+d0)/2;c=(d1-d0)*(q1+q0)/2
            self.assertAlmostEqual(q1*d1-q0*d0,r+c,places=13)

    def test_empty_excluded_stratum(self):
        rows=[]
        for year,assertion,n,h in [(2000,1,10,3),(2002,1,12,2),(2002,0,5,1)]:
            row={'analysis_claim_id':'toy','year':year,'latest_year':year,'assertion':assertion,'n_texts':n}
            row.update({'context_'+f:h for f in FEATURES});rows.append(row)
        meta={'toy':{'source_id':'toy','project':'toy','revised_outcome':'failed','event_year_journal':2001}}
        fit=fit_source(pd.DataFrame(rows),meta,CONFIGS['journal'])
        self.assertEqual(len(fit),3)
        for r in fit.to_dict('records'):
            self.assertFalse(r['decomposition_eligible'])
            self.assertTrue(np.isnan(r['retention_component']))
            self.assertTrue(np.isnan(r['stratum_distribution_component']))
            self.assertAlmostEqual(r['filter_shift'],r['account_retained_weight']+r['account_excluded_incidence'])
            self.assertEqual(r['pre_filter_gap'],0)

    def test_minimum_positive_support(self):
        rows=[]
        for year,assertion,n in [(2000,1,9),(2000,0,100),(2002,1,20),(2002,0,100)]:
            row={'analysis_claim_id':'toy','year':year,'latest_year':year,'assertion':assertion,'n_texts':n}
            row.update({'context_'+f:0 for f in FEATURES});rows.append(row)
        meta={'toy':{'source_id':'toy','project':'toy','revised_outcome':'failed','event_year_journal':2001}}
        self.assertTrue(fit_source(pd.DataFrame(rows),meta,CONFIGS['journal']).empty)

if __name__=='__main__':unittest.main()
