# Scientometrics: revised Springer Nature LaTeX source

Version: 7 October 2026. The main manuscript uses the actual, unchanged
sn-jnl.cls from the author-supplied Springer Nature Version 3.1 (December 2024)
package. Its original template ZIP SHA-256 is
812e76dcaa9c28dc1bff1fb6065d51729b67d4ea140552a05088317414a3ecae.

main.tex uses [pdflatex,sn-basic,lineno], the official class's author-year
interface, with manually verified APA-style bibliography entries embedded in
the same .tex file. The class file is not modified. The sn-apa/apacite route is
not used: apacite is absent from the clean existing local TeX environment.
No BibTeX run is needed for this manually supplied reference list.

main.tex: 18 pages, 39 cited references, 4 figures and 3 tables.
supplementary.tex: 17 pages, 2 figures and 15 tables. This companion document
retains its readable standalone article layout; its main-figure cross-reference
is updated. cover_letter.tex and title_page.tex are unchanged standalone letters/
author details, each one page. This is a submission draft, not a publisher proof.

Compile from this directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
    latexmk -pdf -interaction=nonstopmode -halt-on-error supplementary.tex
    latexmk -pdf -interaction=nonstopmode -halt-on-error cover_letter.tex
    latexmk -pdf -interaction=nonstopmode -halt-on-error title_page.tex

Alternatively run pdflatex twice on each .tex file. On Overleaf, upload the
source ZIP and select the appropriate root .tex document. Keep the local class,
style and figures with their relative paths. All original four PNGs are retained
unchanged; two new vector PDFs display existing frozen counts/results.

Local validation used the existing TeX Live 2026 installation with an empty
TEXMFHOME to avoid an unrelated incompatible user overlay. No private keys,
model APIs, network requests or analysis reruns are needed to compile these files.
The class is distributed with its original LPPL header; its original package
and manual are retained in the author-only provenance directory of the full
delivery. The style file is also an unmodified original template asset.

Fig. 1 was redrawn on 7 October 2026 as an original four-module vector figure. Its fixed population counts and analysis definitions are unchanged. Only the Fig. 1 navigation sentence and caption were edited in the manuscript.

Reference expansion: 12 verified and actually cited works added. The optional references_added_verified.bib exports only those new works; main.tex still embeds the complete 39-entry bibliography and compiles without BibTeX. Author-year citations follow the journal instructions. The figure-redesign assets are unchanged.
